const products = [
  {
    productId: "1A",
    productName: "Abrocitinib 100 mg (28 tablets)",
    calcProductName: "Abrocitinib 100 mg",
    groupName: "Abrocitinib",
    initialCost: 0,
    multiplier: 13,
    usage: 0,
    easiMultipliers: { EASI50: 76, EASI75: 55, EASI90: 32, IGA01: 31 },
  },
  {
    productId: "1B",
    productName: "Abrocitinib 200 mg (28 tablets)",
    calcProductName: "Abrocitinib 200 mg",
    groupName: "Abrocitinib",
    initialCost: 0,
    multiplier: 13,
    usage: 0,
    easiMultipliers: { EASI50: 86, EASI75: 71, EASI90: 49, IGA01: 48 },
  },
  {
    productId: "2A",
    productName: "Baricitinib 2 mg (28 tablets)",
    calcProductName: "Baricitinib 2 mg",
    groupName: "Baricitinib",
    initialCost: 0,
    multiplier: 13,
    usage: 0,
    easiMultipliers: { EASI50: 65, EASI75: 42, EASI90: 16, IGA01: 21 },
  },
  {
    productId: "2B",
    productName: "Baricitinib 4 mg (28 tablets)",
    calcProductName: "Baricitinib 4 mg",
    groupName: "Baricitinib",
    initialCost: 0,
    multiplier: 13,
    usage: 0,
    easiMultipliers: { EASI50: 65, EASI75: 42, EASI90: 22, IGA01: 27 },
  },
  {
    productId: "3A",
    productName: "Dupilumab 300 mg (2 pre-filled pens or syringes)",
    calcProductName: "Dupilumab 300 mg",
    groupName: "Dupilumab",
    initialCost: 0,
    multiplier: 13.5,
    usage: 0,
    easiMultipliers: { EASI50: 79, EASI75: 59, EASI90: 36, IGA01: 35 },
  },
  {
    productId: "4A",
    productName: "Lebrikizumab 250 mg (2 pre-filled pens or syringes)",
    calcProductName: "Lebrikizumab 250 mg 2W",
    groupName: "Lebrikizumab",
    initialCost: 0,
    multiplier: 9.5,
    usage: 0,
    easiMultipliers: { EASI50: 72, EASI75: 55, EASI90: 28, IGA01: 31 },
  },
  {
    productId: "4B",
    productName: "Lebrikizumab 250 mg (4 pre-filled pens or syringes)",
    calcProductName: "Lebrikizumab 250 mg 4W",
    groupName: "Lebrikizumab",
    initialCost: 0,
    multiplier: 10.5,
    usage: 0,
    easiMultipliers: { EASI50: 72, EASI75: 55, EASI90: 28, IGA01: 31 },
  },
  {
    productId: "5A",
    productName: "Tralokinumab 300 mg (2 pre-filled pens or syringes)",
    calcProductName: "Tralokinumab 300 mg 2W",
    groupName: "Tralokinumab", 
    initialCost: 0,
    multiplier: 9,
    usage: 0,
    easiMultipliers: { EASI50: 65, EASI75: 33, EASI90: 16, IGA01: 15 },
  },
  {
    productId: "5B",
    productName: "Tralokinumab 300 mg (2 pre-filled pens or syringes)",
    calcProductName: "Tralokinumab 300 mg 4W",
    groupName: "Tralokinumab", 
    initialCost: 0,
    multiplier: 13.5,
    usage: 0,
    easiMultipliers: { EASI50: 65, EASI75: 33, EASI90: 16, IGA01: 15 },
  },
  {
    productId: "6A",
    productName: "Upadacitinib 15 mg (28 tablets)",
    calcProductName: "Upadacitinib 15 mg",
    groupName: "Upadacitinib",
    initialCost: 0,
    multiplier: 13,
    usage: 0,
    easiMultipliers: { EASI50: 87, EASI75: 66, EASI90: 43, IGA01: 48 },
  },
  {
    productId: "6B",
    productName: "Upadacitinib 30 mg (28 tablets)",
    calcProductName: "Upadacitinib 30 mg",
    groupName: "Upadacitinib",
    initialCost: 0,
    multiplier: 13,
    usage: 0,
    easiMultipliers: { EASI50: 91, EASI75: 76, EASI90: 59, IGA01: 62 },
  },
];

// Function to create an HTML element
function createElement(tag, attributes, innerHTML) {
  const element = document.createElement(tag);
  if (attributes) {
    for (const key in attributes) {
      element.setAttribute(key, attributes[key]);
    }
  }
  if (innerHTML) {
    element.innerHTML = innerHTML;
  }
  return element;
}

// Modified createTable function to support dynamic headers and rows
function createTable(containerSelector, headers, rows) {
  const container = document.querySelector(containerSelector);
  if (!container) {
    console.error(`Container not found: ${containerSelector}`);
    return;
  }

  const table = document.createElement("div");
  table.className = "table";

  // Create header row
  const headerRow = document.createElement("div");
  headerRow.className = "row header";
  headers.forEach((header) => {
    const headerCell = document.createElement("div");
    headerCell.className = "cell";
    headerCell.innerHTML = header;
    headerRow.appendChild(headerCell);
  });
  table.appendChild(headerRow);

  // Create data rows
  rows.forEach((rowData) => {
    const row = document.createElement("div");
    row.className = "row";
    rowData.forEach((cellData) => {
      const cell = document.createElement("div");
      cell.className = "cell";
      if (typeof cellData === "string" || typeof cellData === "number") {
        cell.textContent = cellData;
      } else {
        cell.appendChild(cellData); // For elements like inputs
      }
      row.appendChild(cell);
    });
    table.appendChild(row);
  });

  container.appendChild(table);
}

// Function to format currency
function formatCurrency(amount) {
  return new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format(amount);
}

// Function to show a specific step
function showStep(stepNumber) {
  const steps = document.querySelectorAll('.step');
  steps.forEach((step, index) => {
    step.style.display = index + 1 === stepNumber ? 'block' : 'none';
  });

  // Update step indicators after showing the step
  updateStepIndicators(stepNumber);
}

// Function to update step indicators
function updateStepIndicators(activeStep) {
  const stepContainers = document.querySelectorAll('.step-container');

  stepContainers.forEach((container, index) => {
    const indicator = container.querySelector('div[id^="step-indicator"]'); // Select the step indicator
    if (index + 1 < activeStep) {
      // Replace the label with a checkmark for completed steps
      indicator.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="checkmark"><polyline points="20 6 9 17 4 12"></polyline></svg>';
      indicator.classList.add('completed-step');
      indicator.classList.remove('active-step');
    } else if (index + 1 === activeStep) {
      // Highlight the current step
      indicator.innerHTML = index + 1; // Reset to the step number
      indicator.classList.add('active-step');
      indicator.classList.remove('completed-step');
    } else {
      // Reset future steps
      indicator.innerHTML = index + 1; // Reset to the step number
      indicator.classList.remove('active-step', 'completed-step');
    }
  });
}

// Function to generate step indicators dynamically
function generateStepIndicators() {
  const mainDiv = document.querySelector('.main');
  if (!mainDiv) {
    console.error('Main div not found');
    return;
  }

  const stepsContainer = createElement('div', { class: 'steps' });
  const stepIndicatorContainer = createElement('div', { class: 'step-indicator' });

  const steps = [
    { id: 'step-indicator1', label: '1', text: 'Cost calculator', className: 'active-step' },
    { id: 'step-indicator2', label: '2', text: 'Cost per responder', className: '' },
    { id: 'step-indicator3', label: '3', text: 'Budget considerations', className: '' },
  ];

  steps.forEach((step, index) => {
    const stepContainer = createElement('div', { class: 'step-container' });
    const stepDiv = createElement('div', { id: step.id, class: step.className }, step.label);
    const stepText = createElement('div', { class: 'step-text' }, step.text);

    stepContainer.appendChild(stepDiv);
    stepContainer.appendChild(stepText);
    stepIndicatorContainer.appendChild(stepContainer);

    if (index < steps.length - 1) {
      const hr = createElement('hr');
      stepIndicatorContainer.appendChild(hr);
    }
  });

  stepsContainer.appendChild(stepIndicatorContainer);
  mainDiv.prepend(stepsContainer);
}

// Function to generate steps dynamically
function generateSteps() {
  const mainDiv = document.querySelector('.main');
  if (!mainDiv) {
    console.error('Main div not found');
    return;
  }

  // Step 1
  const step1 = createElement('div', { id: 'step1', class: 'step', style: 'display: block' });
  const step1Header = createElement('h2', null, 'Step 1');
  const step1Description = createElement('p', null, 'Description for Step 1');
  const step1TableContainer = createElement('div', { class: 'table-container' });
  const step1ButtonGroup = createElement('div', { class: 'button-group' });
  const step1CalculateButton = createElement('button', { class: 'calculate-button' }, 'Calculate');
  step1CalculateButton.addEventListener('click', () => showStep(2));

  step1ButtonGroup.appendChild(step1CalculateButton);
  step1.appendChild(step1Header);
  step1.appendChild(step1Description);
  step1.appendChild(step1TableContainer);
  step1.appendChild(step1ButtonGroup);
  mainDiv.appendChild(step1);

  // Step 2
  const step2 = createElement('div', { id: 'step2', class: 'step', style: 'display: none' });
  const step2Header = createElement('h2', null, 'Step 2');
  const step2Description = createElement('p', null, 'Description for Step 2');
  const step2TableContainer = createElement('div', { class: 'table-container' });
  const step2ButtonGroup = createElement('div', { class: 'button-group' });
  const step2PrevButton = createElement('button', { class: 'prev-button' }, 'Previous');
  const step2NextButton = createElement('button', { class: 'next-button' }, 'Next');
  step2PrevButton.addEventListener('click', () => showStep(1));
  step2NextButton.addEventListener('click', () => showStep(3));

  step2ButtonGroup.appendChild(step2PrevButton);
  step2ButtonGroup.appendChild(step2NextButton);
  step2.appendChild(step2Header);
  step2.appendChild(step2Description);
  step2.appendChild(step2TableContainer);
  step2.appendChild(step2ButtonGroup);
  mainDiv.appendChild(step2);

  // Step 3
  const step3 = createElement('div', { id: 'step3', class: 'step', style: 'display: none' });
  const step3Header = createElement('h2', null, 'Step 3');
  const step3Description = createElement('p', null, 'Description for Step 3');
  const step3TableContainer = createElement('div', { class: 'table-container' });
  const step3ButtonGroup = createElement('div', { class: 'button-group' });
  const step3PrevButton = createElement('button', { class: 'prev-button' }, 'Previous');
  step3PrevButton.addEventListener('click', () => showStep(2));

  step3ButtonGroup.appendChild(step3PrevButton);
  step3.appendChild(step3Header);
  step3.appendChild(step3Description);
  step3.appendChild(step3TableContainer);
  step3.appendChild(step3ButtonGroup);
  mainDiv.appendChild(step3);
}

// Unified data structure for dropdowns across all steps
const dropdownData = {
  step1: [
    {
      label: 'National',
      value: 'National',
      subOptions: [
        { name: 'England', population: 10 },
        { name: 'Wales', population: 500 },
        { name: 'Northern Ireland', population: 1 },
      ],
    },
    {
      label: 'England ICB',
      value: 'EnglandICB',
      subOptions: [
        { name: 'England', population: 64 },
        { name: 'Wales', population: 543 },
        { name: 'Northern Ireland', population: 23 },
      ],
    },
    {
      label: 'NHSE Regions',
      value: 'NHSERegions',
      subOptions: [
        { name: 'England', population: 43 },
        { name: 'Wales', population: 64 },
        { name: 'Northern Ireland', population: 214 },
      ],
    },
    {
      label: 'Wales Health Boards',
      value: 'WalesHealthBoards',
      subOptions: [
        { name: 'England', population: 7 },
        { name: 'Wales', population: 8 },
        { name: 'Northern Ireland', population: 3 },
      ],
    },
    {
      label: 'NI Health and Social Care Trusts',
      value: 'NIHealthandSocialCareTrusts',
      subOptions: [
        { name: 'England', population: 2 },
        { name: 'Wales', population: 3 },
        { name: 'Northern Ireland', population: 4 },
      ],
    },
    {
      label: 'LA Wales',
      value: 'LAWales',
      subOptions: [
        { name: 'England', population: 5 },
        { name: 'Wales', population: 6 },
        { name: 'Northern Ireland', population: 7 },
      ],
    },
    {
      label: 'LA NI',
      value: 'LANI',
      subOptions: [
        { name: 'England', population: 8 },
        { name: 'Wales', population: 9 },
        { name: 'Northern Ireland', population: 10 },
      ],
    },
    {
      label: 'LA England',
      value: 'LAEngland',
      subOptions: [
        { name: 'England', population: 11 },
        { name: 'Wales', population: 12 },
        { name: 'Northern Ireland', population: 13 },
      ],
    },
    {
      label: 'England CCGs',
      value: 'EnglandCCGs',
      subOptions: [
        { name: 'England', population: 14 },
        { name: 'Wales', population: 15 },
        { name: 'Northern Ireland', population: 16 },
      ],
    },
  ],
  step2: [
    { label: 'EASI 50', value: 'easi50' },
    { label: 'EASI 75', value: 'easi75' },
    { label: 'EASI 90', value: 'easi90' },
    { label: 'IGA 0/1', value: 'iga01' },
  ],
  step3: [
    { label: 'EASI 50', value: 'easi50' },
    { label: 'EASI 75', value: 'easi75' },
    { label: 'EASI 90', value: 'easi90' },
    { label: 'IGA 0/1', value: 'iga01' },
    { label: 'Acquisition Cost', value: 'acquisitionCost'},
  ],
};

// Function to create a dropdown
function createDropdown(containerSelector, options, onSelect) {
  const container = containerSelector ? document.querySelector(containerSelector) : null;
  if (containerSelector && !container) {
    console.error(`Container not found: ${containerSelector}`);
    return;
  }

  const dropdown = createElement('div', { class: 'dropdown' });
  const selected = createElement('div', { class: 'dropdown-selected' }, 'Select an option');
  const optionsContainer = createElement('div', { class: 'dropdown-options', style: 'display: none;' });

  // Populate options
  options.forEach((option) => {
    const optionDiv = createElement('div', { class: 'dropdown-option', 'data-value': option.value }, option.label);
    optionDiv.addEventListener('click', () => {
      selected.textContent = option.label;
      optionsContainer.style.display = 'none';
      if (onSelect) onSelect(option.value); // Trigger callback with selected value
    });
    optionsContainer.appendChild(optionDiv);
  });

  // Toggle dropdown visibility
  selected.addEventListener('click', () => {
    optionsContainer.style.display = optionsContainer.style.display === 'none' ? 'block' : 'none';
  });

  dropdown.appendChild(selected);
  dropdown.appendChild(optionsContainer);
  if (container) {
    container.appendChild(dropdown);
  }

  console.log(`Dropdown created in container: ${containerSelector}`);
  return dropdown;
}

// Function to update an existing dropdown with new options
function updateDropdown(dropdownSelector, options, populationDisplay) {
  const dropdown = document.querySelector(dropdownSelector);
  if (!dropdown) {
    console.error(`Dropdown not found: ${dropdownSelector}`);
    return;
  }

  const optionsContainer = dropdown.querySelector('.dropdown-options');
  if (!optionsContainer) {
    console.error('Options container not found in dropdown');
    return;
  }

  // Clear existing options
  optionsContainer.innerHTML = '';

  // Populate new options
  options.forEach((option) => {
    const optionDiv = createElement('div', { class: 'dropdown-option', 'data-value': option.value }, option.label);
    optionDiv.addEventListener('click', () => {
      const selected = dropdown.querySelector('.dropdown-selected');
      selected.textContent = option.label;
      optionsContainer.style.display = 'none';

      // Update the population display
      if (populationDisplay && option.population !== undefined) {
        populationDisplay.textContent = `Population: ${option.population}`;
      }

      console.log(`Dropdown option selected: ${option.value}`);
    });
    optionsContainer.appendChild(optionDiv);
  });

  console.log(`Dropdown updated: ${dropdownSelector}`);
}

// Modify setupDropdowns to pass the populationDisplay element
function setupDropdowns() {
  console.log('Setting up dropdowns...');

  // Step 1: Two connected dropdowns
  const step1DropdownContainer = createElement('div', { class: 'dropdown-container' });

  const populationDisplay = createElement('div', { class: 'population-display' }, 'Population: N/A');

  const dropdown1 = createDropdown(null, dropdownData.step1.map(option => ({
    label: option.label,
    value: option.value,
  })), (value) => {
    console.log(`Step 1 Dropdown 1 selected: ${value}`);
    // Find the selected option's sub-options
    const selectedOption = dropdownData.step1.find(option => option.value === value);
    const subOptions = selectedOption ? selectedOption.subOptions.map(subOption => ({
      label: subOption.name,
      value: subOption.name,
      population: subOption.population, // Pass population data
    })) : [];
    // Update the second dropdown with sub-options
    updateDropdown('#step1 .table-container .dropdown-container .dropdown:nth-child(2)', subOptions, populationDisplay);
    // Reset population display
    populationDisplay.textContent = 'Population: N/A';
  });

  const dropdown2 = createDropdown(null, [], (value) => {
    console.log(`Step 1 Dropdown 2 selected: ${value}`);
    // Find the selected sub-option
    const selectedOption = dropdownData.step1.flatMap(option => option.subOptions).find(subOption => subOption.name === value);
    if (selectedOption) {
      populationDisplay.textContent = `Population: ${selectedOption.population}`;
    }
  });

  step1DropdownContainer.appendChild(dropdown1);
  step1DropdownContainer.appendChild(dropdown2);

  const step1Container = document.querySelector('#step1 .table-container');
  if (step1Container) {
    step1Container.appendChild(step1DropdownContainer);
    step1Container.appendChild(populationDisplay);
  }

  // Step 2: Single dropdown
  createDropdown('#step2 .table-container', dropdownData.step2, (value) => {
    console.log(`Step 2 Dropdown selected: ${value}`);
    // Update results or trigger logic for Step 2
  });

  // Step 3: Single dropdown
  createDropdown('#step3 .table-container', dropdownData.step3, (value) => {
    console.log(`Step 3 Dropdown selected: ${value}`);
    // Update results or trigger logic for Step 3
  });

  console.log('Dropdowns setup complete.');
}

// Add tables to Step 1
function addStep1Table() {
  const rows = products.map((product) => [
    product.productName,
    createElement("input", { type: "number", class: "cost-input", placeholder: "0", step: "0.01" }),
  ]);
  createTable("#step1 .table-container", ["<strong>Treatment</strong>", "<strong>Enter the price you pay for one pack of treatment (£)</strong><br>All cost fields must be filled )"], rows);
}

// Add tables to Step 2
function addStep2Tables() {
  // First table
  const rows1 = products.map((product) => [
    product.productName,
    createElement("div", { class: "cost1" }, "0"), // Placeholder for cost1
    createElement("div", { class: "cost2" }, "0"), // Placeholder for cost2
    createElement("input", { type: "number", class: "cost-input", placeholder: "0", step: "0.01" }),
  ]);
  createTable("#step2 .table-container", ["<strong>Treatment</strong>", "<strong>Cost 1</strong>", "<strong>Cost 2</strong>", "<strong>Input</strong>"], rows1);

  // Second table
  const rows2 = [
    [createElement("div", { class: "avg-cost1" }, "0"), createElement("div", { class: "avg-cost2" }, "0")],
    [createElement("div", { class: "avg-cost1" }, "0"), createElement("div", { class: "avg-cost2" }, "0")],
  ];
  createTable("#step2 .table-container", ["Average1", "Average2"], rows2);
}

// Add tables to Step 3
function addStep3Table() {
  const rows = products.map((product) => [
    product.productName,
    createElement("input", { type: "number", class: "input1", placeholder: "0", step: "0.01" }),
    createElement("div", { class: "cost1" }, "0"), // Placeholder for cost1
    createElement("input", { type: "number", class: "input2", placeholder: "0", step: "0.01" }),
    createElement("div", { class: "cost2" }, "0"), // Placeholder for cost2
  ]);
  createTable("#step3 .table-container", ["<strong>Product Name</strong>", "<strong>Input 1</strong>", "<strong>Cost 1</strong>", "<strong>Input 2</strong>", "<strong>Cost 2</strong>"], rows);
}

// Ensure steps are generated before setting up dropdowns
generateSteps();

// Call setupDropdowns after generating steps
setupDropdowns();

// Call functions to add tables to each step
addStep1Table();
addStep2Tables();
addStep3Table();

// Initialize the steps and indicators
generateStepIndicators();

