const products = [
  {
    productId: "1A",
    productName: "Abrocitinib 100 mg (28 tablets)",
    calcProductName: "Abrocitinib 100 mg",
    initialCost: 0,
    multiplier: 13,
    usage: 0,
    easiMultipliers: { EASI50: 76, EASI75: 55, EASI90: 32, IGA01: 31 },
  },
  {
    productId: "1B",
    productName: "Abrocitinib 200 mg (28 tablets)",
    calcProductName: "Abrocitinib 200 mg",
    initialCost: 0,
    multiplier: 13,
    usage: 0,
    easiMultipliers: { EASI50: 86, EASI75: 71, EASI90: 49, IGA01: 48 },
  },
  {
    productId: "2A",
    productName: "Baricitinib 2 mg (28 tablets)",
    calcProductName: "Baricitinib 2 mg",
    initialCost: 0,
    multiplier: 13,
    usage: 0,
    easiMultipliers: { EASI50: 65, EASI75: 42, EASI90: 16, IGA01: 21 },
  },
  {
    productId: "2B",
    productName: "Baricitinib 4 mg (28 tablets)",
    calcProductName: "Baricitinib 4 mg",
    initialCost: 0,
    multiplier: 13,
    usage: 0,
    easiMultipliers: { EASI50: 65, EASI75: 42, EASI90: 22, IGA01: 27 },
  },
  {
    productId: "3A",
    productName: "Dupilumab 300 mg (2 pre-filled pens or syringes)",
    calcProductName: "Dupilumab 300 mg",
    initialCost: 0,
    multiplier: 13.5,
    usage: 0,
    easiMultipliers: { EASI50: 79, EASI75: 59, EASI90: 36, IGA01: 35 },
  },
  {
    productId: "4A",
    productName: "Lebrikizumab 250 mg (2 pre-filled pens or syringes)",
    calcProductName: "Lebrikizumab 250 mg 2W",
    initialCost: 0,
    multiplier: 9.5,
    usage: 0,
    easiMultipliers: { EASI50: 72, EASI75: 55, EASI90: 28, IGA01: 31 },
  },
  {
    productId: "4B",
    productName: "Lebrikizumab 250 mg (4 pre-filled pens or syringes)",
    calcProductName: "Lebrikizumab 250 mg 4W",
    initialCost: 0,
    multiplier: 10.5,
    usage: 0,
    easiMultipliers: { EASI50: 72, EASI75: 55, EASI90: 28, IGA01: 31 },
  },
  {
    productId: "5A",
    productName: "Tralokinumab 300 mg (2 pre-filled pens or syringes)",
    calcProductName: "Tralokinumab 300 mg 2W",
    initialCost: 0,
    multiplier: 9,
    usage: 0,
    easiMultipliers: { EASI50: 65, EASI75: 33, EASI90: 16, IGA01: 15 },
  },
  {
    productId: "5B",
    productName: "Tralokinumab 300 mg (2 pre-filled pens or syringes)",
    calcProductName: "Tralokinumab 300 mg 4W",
    initialCost: 0,
    multiplier: 13.5,
    usage: 0,
    easiMultipliers: { EASI50: 65, EASI75: 33, EASI90: 16, IGA01: 15 },
  },
  {
    productId: "6A",
    productName: "Upadacitinib 15 mg (28 tablets)",
    calcProductName: "Upadacitinib 15 mg",
    initialCost: 0,
    multiplier: 13,
    usage: 0,
    easiMultipliers: { EASI50: 87, EASI75: 66, EASI90: 43, IGA01: 48 },
  },
  {
    productId: "6B",
    productName: "Upadacitinib 30 mg (28 tablets)",
    calcProductName: "Upadacitinib 30 mg",
    initialCost: 0,
    multiplier: 13,
    usage: 0,
    easiMultipliers: { EASI50: 91, EASI75: 76, EASI90: 59, IGA01: 62 },
  },
];
// Function to create an HTML element
function createElement(tag, attributes, innerHTML) {
  const element = document.createElement(tag);
  if (attributes) {
    for (const key in attributes) {
      element.setAttribute(key, attributes[key]);
    }
  }
  if (innerHTML) {
    element.innerHTML = innerHTML;
  }
  return element;
}
// Function to format currency
function formatCurrency(amount) {
  return new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format(amount);
}
// Page transition and Step indicator logic
document.querySelectorAll('.next-step, .prev-step').forEach(button => {
  button.addEventListener('click', () => {
    if (button.classList.contains('next-step') && !selectedPopulation) {
      messageDiv.style.display = 'block'; // Show the message
      return;
    }
    messageDiv.style.display = 'none'; // Hide the message
    const currentStep = button.closest('.step-one, .step-two, .step-three');
    const targetStep = button.classList.contains('next-step') ? currentStep.nextElementSibling : currentStep.previousElementSibling;
    currentStep.classList.add('hide');
    targetStep.classList.remove('hide');
    updateStepIndicators();

    // Append the Acquisition Cost table to #step3 when transitioning to step3
    if (targetStep.id === 'step3') {
      const step3Container = document.getElementById('step3');
      if (!step3Container.querySelector('.acquisition-cost-table')) {
        const acquisitionCostTableContainer = document.createElement('div');
        acquisitionCostTableContainer.className = 'acquisition-cost-table';
        step3Container.appendChild(acquisitionCostTableContainer);
        createAcquisitionCostTable(); // Create the table inside the container
      }
    }
  });
});

const steps = [document.getElementById('step1'), document.getElementById('step2'), document.getElementById('step3')];
const stepIndicators = [document.getElementById('step-indicator1'), document.getElementById('step-indicator2'), document.getElementById('step-indicator3')];
stepIndicators.forEach((indicator, index) => indicator.innerHTML = index + 1);

function updateStepIndicators() {
  const checkmarkSVG = `<svg class="checkmark" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"
      stroke-linejoin="round"></path>
  </svg>`;

  stepIndicators.forEach((indicator, index) => {
    if (!steps[index].classList.contains('hide')) {
      indicator.innerHTML = index + 1;
      indicator.classList.add('active-step');
    } else {
      indicator.innerHTML = index + 1;
      indicator.classList.remove('active-step');
    }

    // Add checkmark to all previous steps
    if (index < steps.findIndex(step => !step.classList.contains('hide'))) {
      indicator.innerHTML = checkmarkSVG;
      indicator.classList.add('active-step');
    }
  });
}
updateStepIndicators();

function createDropdownGroup() {
  const dropdownGroup = createElement('div', { class: 'dropdown-group' });
  const dropdownContainer = createElement('div', { class: 'dropdown-container' });
  const dropdownLabel = createElement('p', null, '<strong>Select an AD outcome&nbsp;</strong>');
  const customDropdown = createElement('div', { class: 'custom-dropdown' });
  const dropdownBtn = createElement('button', { type: 'button', class: 'dropdown-btn' }, '<span>EASI 50</span>');
  const dropdownContent = createElement('div', { class: 'dropdown-content' });

  const outcomes = ['EASI 50', 'EASI 75', 'EASI 90', 'IGA 0/1'];

  outcomes.forEach(outcome => {
    const outcomeDiv = createElement('div', { class: 'option' }, `<span>${outcome}</span>`);
    dropdownContent.appendChild(outcomeDiv);
  });

  customDropdown.appendChild(dropdownBtn);
  customDropdown.appendChild(dropdownContent);
  dropdownContainer.appendChild(dropdownLabel);
  dropdownContainer.appendChild(customDropdown);
  dropdownGroup.appendChild(dropdownContainer);

  // Toggle dropdown visibility
  dropdownBtn.addEventListener('click', () => {
    dropdownContent.classList.toggle('show');
  });

  // Use event delegation for option selection
  dropdownContent.addEventListener('click', (e) => {
    if (e.target.closest('.option')) {
      const selectedOption = e.target.closest('.option');
      const selectedText = selectedOption.textContent.trim();
      dropdownBtn.innerHTML = `<span>${selectedText}</span>`;
      calculateAllCosts();
      dropdownContent.classList.remove('show');
    }
  });

  return dropdownGroup;
}

function createStepHeader(stepId) {
  const stepHeader = createElement('div', { class: 'step-header' });
  const outcomeBox = createElement('div', { class: 'outcome-box' });
  const outcomeTitle = createElement('h3', { class: 'outcome-title' }, 'Cost per responder');
  const outcomePopulation = createElement('div', { class: 'outcome-population' }, 'All outputs are modelled over a 1-year time frame');
  const calcMethodLink = createElement('a', { href: '#', class: 'calc-method-link' }, 'Methodology');
  const outcomeSelect = createElement('div', { class: 'outcome-select' });

  const dropdownGroup = createDropdownGroup(); // Call the dropdown creation function here

  outcomeSelect.appendChild(dropdownGroup);
  outcomeBox.appendChild(outcomeTitle);
  outcomeBox.appendChild(outcomePopulation);
  outcomeBox.appendChild(calcMethodLink);
  outcomeBox.appendChild(outcomeSelect);
  stepHeader.appendChild(outcomeBox);

  const stepPopulation = createElement('div', { id: stepId, class: 'result' });
  stepHeader.appendChild(stepPopulation);

  return stepHeader;
}
function prependStepHeaders() {
  const step2 = document.getElementById('step2');
  const step3 = document.getElementById('step3');

  if (step2) {
    step2.prepend(createStepHeader('step2-population'));
  }

  if (step3) {
    step3.prepend(createStepHeader('step3-population'));
  }
}
prependStepHeaders();

const container = document.getElementById("dropdownContainer");
const resultDiv = document.getElementById("populationResult");
const cities = {
  National: [
    { name: 'England', population: 10 },
    { name: 'Wales', population: 500 },
    { name: 'Northern Ireland', population: 1 },
  ],
  EnglandICB: [
    { name: 'England', population: 64 },
    { name: 'Wales', population: 543 },
    { name: 'Northern Ireland', population: 23 },
  ],
  NHSERegions: [
    { name: 'England', population: 43 },
    { name: 'Wales', population: 64 },
    { name: 'Northern Ireland', population: 214 },
  ],
  WalesHealthBoards: [
    { name: 'England', population: 134 },
    { name: 'Wales', population: 111 },
    { name: 'Northern Ireland', population: 521 },
  ],
  NIHealthandSocialCareTrusts: [
    { name: 'England', population: 123 },
    { name: 'Wales', population: 321 },
    { name: 'Northern Ireland', population: 320 },
  ],
  LAWales: [
    { name: 'England', population: 423 },
    { name: 'Wales', population: 21 },
    { name: 'Northern Ireland', population: 432 },
  ],
  LANI: [
    { name: 'England', population: 32 },
    { name: 'Wales', population: 12 },
    { name: 'Northern Ireland', population: 19 },
  ],
  LAEngland: [
    { name: 'England', population: 6 },
    { name: 'Wales', population: 5 },
    { name: 'Northern Ireland', population: 4 },
  ],
  EnglandCCGs: [
    { name: 'England', population: 3 },
    { name: 'Wales', population: 2 },
    { name: 'Northern Ireland', population: 1 },
  ]
};

const { dropdown: regionDropdown, selected: regionSelected, optionsDiv: regionOptions } = createDropdown(
  "regionDropdown",
  "Select Region",
  [
    { label: 'National', value: 'National' },
    { label: 'England ICB', value: 'EnglandICB' },
    { label: 'NHSE Regions', value: 'NHSERegions' },
    { label: 'Wales Health Boards', value: 'WalesHealthBoards' },
    { label: 'NI Health and Social Care Trusts', value: 'NIHealthandSocialCareTrusts' },
    { label: 'LA Wales', value: 'LAWales' },
    { label: 'LA NI', value: 'LANI' },
    { label: 'LA England', value: 'LAEngland' },
    { label: 'England CCGs', value: 'EnglandCCGs' },
  ]
);

const { dropdown: cityDropdown, selected: citySelected, optionsDiv: cityOptions } = createDropdown(
  "cityDropdown",
  "Select City"
);

function createDropdown(id, placeholder, options = []) {
  const dropdown = document.createElement('div');
  dropdown.classList.add('dropdown');
  dropdown.id = id;

  const selected = document.createElement('div');
  selected.classList.add('selected');
  selected.innerText = placeholder;

  const optionsDiv = document.createElement('div');
  optionsDiv.classList.add('options');

  options.forEach(option => {
    const optionElement = document.createElement('div');
    optionElement.classList.add('option');
    optionElement.dataset.value = option.value;
    optionElement.textContent = option.label;
    optionsDiv.appendChild(optionElement);
  });

  dropdown.appendChild(selected);
  dropdown.appendChild(optionsDiv);
  container.appendChild(dropdown);

  return { dropdown, selected, optionsDiv };
}

function setupDropdown(dropdown) {
  const selected = dropdown.querySelector('.selected');
  const options = dropdown.querySelector('.options');

  selected.addEventListener('click', () => {
    options.style.display = options.style.display === 'block' ? 'none' : 'block';
  });

  document.addEventListener('click', (e) => {
    if (!dropdown.contains(e.target)) {
      options.style.display = 'none';
    }
  });

  options.addEventListener('click', (e) => {
    if (e.target.classList.contains('option')) {
      selected.innerText = e.target.textContent;
      selected.dataset.value = e.target.dataset.value;
      options.style.display = 'none';
    }
  });
}

let selectedPopulation = null; // Variable to store the selected population

setupDropdown(regionDropdown);
setupDropdown(cityDropdown);

regionOptions.addEventListener('click', (e) => {
  if (e.target.classList.contains('option')) {
    const selectedRegion = e.target.dataset.value;
    citySelected.textContent = 'Select City';
    cityOptions.innerHTML = '';
    resultDiv.innerHTML = '&nbsp;';

    if (cities[selectedRegion]) {
      cities[selectedRegion].forEach(city => {
        const cityDiv = document.createElement('div');
        cityDiv.classList.add("option");
        cityDiv.dataset.value = city.population;
        cityDiv.textContent = city.name;
        cityOptions.appendChild(cityDiv);
      });

      cityOptions.style.display = 'block';

      // Automatically select the first option from the second dropdown
      const firstCityOption = cityOptions.querySelector('.option');
      if (firstCityOption) {
        citySelected.textContent = firstCityOption.textContent;
        citySelected.dataset.value = firstCityOption.dataset.value;
        resultDiv.textContent = `${firstCityOption.dataset.value}`;
        selectedPopulation = firstCityOption.dataset.value; // Update the selected population

        // Update the element with id "step2-population"
        const step2PopulationElement = document.getElementById('step2-population');
        const step3PopulationElement = document.getElementById('step3-population');
        [step2PopulationElement, step3PopulationElement].forEach(element => {
          if (element) {
            element.textContent = selectedPopulation;
          }
        });
      }
    }
  }
});

cityOptions.addEventListener('click', (e) => {
  if (e.target.classList.contains('option')) {
    const population = e.target.dataset.value;
    resultDiv.textContent = `${population}`;
    selectedPopulation = population; // Update the selected population

    // Update the element with id "step2-population"
    const step2PopulationElement = document.getElementById('step2-population');
    const step3PopulationElement = document.getElementById('step3-population');
    [step2PopulationElement, step3PopulationElement].forEach(element => {
      if (element) {
        element.textContent = selectedPopulation;
      }
    });
  }
});

// Add a new element for the message under the dropdown
const messageDiv = createElement("div", { id: "populationMessage", style: "color: red; font-size: small; display: none;" }, "Please select the population");
container.append(messageDiv);


function createTable(containerSelector, headers, rows) {
  const container = document.querySelector(containerSelector);
  const headerRow = document.createElement("div");
  headerRow.className = "row";
  headers.forEach((header) => {
    const headerCell = document.createElement("div");
    headerCell.className = "cell";
    headerCell.innerHTML = header;
    headerRow.appendChild(headerCell);
  });
  container.appendChild(headerRow);

  rows.forEach((rowData) => {
    const row = document.createElement("div");
    row.className = "row";
    row.id = `row-${container.children.length}`;
    rowData.forEach((cellData) => {
      const cell = document.createElement("div");
      cell.className = "cell";
      if (typeof cellData === "string") {
        cell.textContent = cellData;
      } else {
        cell.appendChild(cellData);
      }
      row.appendChild(cell);
    });
    container.appendChild(row);
  });
}

function createInitialTable() {
  const headers = [
    "<strong>Treatment</strong>",
    "<p><strong>Enter the price you pay for one pack of treatment (£)</strong></p> <p>All cost fields must be filled</p>",
  ];

  // Group products visually
  const groupedProducts = [
    { groupName: "Abrocitinib 100 mg (28 tablets)", products: ["1A"] },
    { groupName: "Abrocitinib 200 mg (28 tablets)", products: ["1B"] },
    { groupName: "Baricitinib 2 mg (28 tablets)", products: ["2A"] },
    { groupName: "Baricitinib 4 mg (28 tablets)", products: ["2B"] },
    { groupName: "Dupilumab 300 mg (2 pre-filled pens or syringes)", products: ["3A"] },
    { groupName: "Lebrikizumab 250 mg (2 pre-filled pens or syringes)", products: ["4A", "4B"] },
    { groupName: "Tralokinumab 300 mg (2 pre-filled pens or syringes)", products: ["5A", "5B"] },
    { groupName: "Upadacitinib 15 mg (28 tablets)", products: ["6A"] },
    { groupName: "Upadacitinib 30 mg (28 tablets)", products: ["6B"] },
  ];

  const rows = groupedProducts.map((group) => [
    group.groupName,
    (() => {
      const container = document.createElement("div");
      container.className = "input-container";
      const span = document.createElement("span");
      span.className = "currency";
      span.textContent = "£";
      const input = document.createElement("input");
      input.type = "number";
      input.placeholder = 0;
      input.dataset.products = group.products.join(","); // Store all product IDs in the dataset
      input.className = "initial-cost";

      // Add event listener to update all grouped products' initial costs
      input.addEventListener("input", (e) => {
        const value = e.target.value;
        group.products.forEach((productId) => {
          const productInput = document.querySelector(`.initial-cost[data-product="${productId}"]`);
          if (productInput) {
            productInput.value = value;
          }
        });
      });

      container.appendChild(span);
      container.appendChild(input);
      return container;
    })(),
  ]);

  createTable(".initial-table", headers, rows);
}

function createCalcTable() {
  const headers = [
    "<strong>Treatment</strong>",
    "Cost<br>per responder",
    "Cost<br>per responding population",
    "Usage",
  ];
  const rows = products.map((product) => [
    product.calcProductName,
    (() => {
      const cell = document.createElement("div");
      cell.dataset.product = product.productId;
      cell.className = "cost-per-responder";
      cell.textContent = formatCurrency(0);
      return cell;
    })(),
    (() => {
      const cell = document.createElement("div");
      cell.dataset.product = product.productId;
      cell.className = "cost-per-responding-population";
      cell.textContent = formatCurrency(0);
      return cell;
    })(),
    (() => {
      const container = document.createElement("div");
      container.className = "input-container";
      const span = document.createElement("span");
      span.className = "usage";
      span.textContent = "%";
      const input = document.createElement("input");
      input.type = "number";
      input.placeholder = 0;
      input.dataset.product = product.productId;
      input.className = "usage-input";

      // Initialize 3A with 100 and disable it
      if (product.productId === "3A") {
        input.value = 100;
      } else {
        // Initialize complementary products with different values
        const complementaryProductId = findComplementaryProduct(product.productId);
        if (complementaryProductId) {
          if (product.productId === "1A") {
            input.value = 70; // Example: Set 1A to 60%
          } else if (product.productId === "1B") {
            input.value = 30; // Example: Set 1B to 40%
          } else if (product.productId === "2A") {
            input.value = 50; // Example: Set 2A to 70%
          } else if (product.productId === "2B") {
            input.value = 50; // Example: Set 2B to 30%
          } else if (product.productId === "4A") {
            input.value = 80; // Example: Set 4A to 50%
          } else if (product.productId === "4B") {
            input.value = 20; // Example: Set 4B to 50%
          } else if (product.productId === "5A") {
            input.value = 80; // Example: Set 5A to 50%
          } else if (product.productId === "5B") {
            input.value = 20; // Example: Set 5B to 50%
          } else if (product.productId === "6A") {
            input.value = 30; // Example: Set 6A to 50%
          } else if (product.productId === "6B") {
            input.value = 70; // Example: Set 6B to 50%
          }
        }
      }

      container.appendChild(span);
      container.appendChild(input);
      return container;
    })(),
  ]);
  createTable(".calc-table", headers, rows);

  // Add event listeners to link complementary inputs
  linkComplementaryInputs();
}

function createAveragesTable() {
  const headers = ["Result", "Calculation"];
  const rows = [
    [
      createElement("div", { id: "product1A-product1B-perResponder" }, formatCurrency(0)),
      createElement("div", { id: "product1A-product1B-calculation" }, formatCurrency(0)),
    ],
    [
      createElement("div", { id: "product2A-product2B-perResponder" }, formatCurrency(0)),
      createElement("div", { id: "product2A-product2B-calculation" }, formatCurrency(0)),
    ],
    [
      createElement("div", { id: "product3A-perResponder" }, formatCurrency(0)),
      createElement("div", { id: "product3A-calculation" }, formatCurrency(0)),
    ],
    [
      createElement("div", { id: "product4A-product4B-perResponder" }, formatCurrency(0)),
      createElement("div", { id: "product4A-product4B-calculation" }, formatCurrency(0)),
    ],
    [
      createElement("div", { id: "product5A-product5B-perResponder" }, formatCurrency(0)),
      createElement("div", { id: "product5A-product5B-calculation" }, formatCurrency(0)),
    ],
    [
      createElement("div", { id: "product6A-product6B-perResponder" }, formatCurrency(0)),
      createElement("div", { id: "product6A-product6B-calculation" }, formatCurrency(0)),
    ],
  ];
  createTable(".averages", headers, rows);
}

function createAcquisitionCostTable() {
  const headers = [
    "<strong>Treatment</strong>",
    "Usage 1 (%)",
    "Average Cost 1 (£)",
    "Usage 2 (%)",
    "Average Cost 2 (£)",
  ];

  const treatments = [
    "Abrocitinib (100 mg or 200 mg)",
    "Baricitinib (2 mg or 4 mg)",
    "Dupilumab (300 mg)",
    "Lebrikizumab (250 mg)",
    "Tralokinumab (300 mg)",
    "Upadacitinib (15 mg or 30 mg)",
  ];

  const rows = treatments.map((treatment, index) => [
    treatment,
    (() => {
      const input = document.createElement("input");
      input.type = "number";
      input.placeholder = "0";
      input.className = `currentUsage-input step3-currentUsage-${index}`;
      input.addEventListener("input", () => updateAcquisitionCosts());
      return input;
    })(),
    (() => {
      const cell = document.createElement("div");
      cell.className = `average-cost1 step3-cost1-${index}`;
      cell.textContent = formatCurrency(0);
      return cell;
    })(),
    (() => {
      const input = document.createElement("input");
      input.type = "number";
      input.placeholder = "0";
      input.className = `potentialUsage-input step3-potentialUsage-${index}`;
      input.addEventListener("input", () => updateAcquisitionCosts());
      return input;
    })(),
    (() => {
      const cell = document.createElement("div");
      cell.className = `average-cost2 step3-cost2-${index}`;
      cell.textContent = formatCurrency(0);
      return cell;
    })(),
  ]);

  createTable(".acquisition-cost-table", headers, rows);
}

// Utility function to update DOM elements
function updateDOM(selector, value) {
  const element = document.querySelector(selector);
  if (element) {
    element.textContent = formatCurrency(value);
  }
}

// Consolidated function to calculate all costs
function calculateAllCosts() {
  // Get the selected EASI outcome index
  const selectedEASIOutcomeIndex = Array.from(document.querySelectorAll('.custom-dropdown .dropdown-content .option'))
    .findIndex(option => option.querySelector('span').textContent === document.querySelector('.custom-dropdown .dropdown-btn span').textContent);

  // Calculate costs for all products
  products.forEach((product) => {
    // Find the shared initial-cost input for grouped products
    const sharedInput = document.querySelector(`.initial-cost[data-products*="${product.productId}"]`);
    const initialCost = parseFloat(sharedInput?.value || 0);
    const usage = parseFloat(document.querySelector(`.usage-input[data-product="${product.productId}"]`)?.value || 0);

    // Calculate costPerPatient
    const costPerPatient = initialCost * product.multiplier;

    // Get the EASI multiplier
    const easiMultiplierKeys = Object.keys(product.easiMultipliers);
    const easiMultiplier = product.easiMultipliers[easiMultiplierKeys[selectedEASIOutcomeIndex]] || 1.0;

    // Calculate all cost metrics
    const costPerResponder = (costPerPatient / easiMultiplier) * 100;
    const costPerPopulation = costPerResponder * (selectedPopulation || 0);
    const usagePerResponder = (costPerResponder / 100) * usage;
    const costPerUsage = costPerPatient * (usage / 100);

    // Update the product object with calculated values
    product.usagePerResponder = usagePerResponder;
    product.costPerUsage = costPerUsage;

    // Update the UI for individual product costs
    updateDOM(`.cost-per-responder[data-product="${product.productId}"]`, costPerResponder);
    updateDOM(`.cost-per-responding-population[data-product="${product.productId}"]`, costPerPopulation);
  });

  // Calculate combined costs for paired products
  const productPairs = [
    { productA: products[0], productB: products[1], perResponderId: "product1A-product1B-perResponder", calculationId: "product1A-product1B-calculation" },
    { productA: products[2], productB: products[3], perResponderId: "product2A-product2B-perResponder", calculationId: "product2A-product2B-calculation" },
    { productA: products[5], productB: products[6], perResponderId: "product4A-product4B-perResponder", calculationId: "product4A-product4B-calculation" },
    { productA: products[7], productB: products[8], perResponderId: "product5A-product5B-perResponder", calculationId: "product5A-product5B-calculation" },
    { productA: products[9], productB: products[10], perResponderId: "product6A-product6B-perResponder", calculationId: "product6A-product6B-calculation" }
  ];

  productPairs.forEach(pair => {
    const combinedCostPerResponder = pair.productA.usagePerResponder + pair.productB.usagePerResponder;
    updateDOM(`#${pair.perResponderId}`, combinedCostPerResponder);

    const combinedCalculation = selectedPopulation * combinedCostPerResponder;
    updateDOM(`#${pair.calculationId}`, combinedCalculation);
  });

  // Single product calculation for 3A
  const product3A = products[4];
  updateDOM("#product3A-perResponder", product3A.usagePerResponder);
  updateDOM("#product3A-calculation", product3A.usagePerResponder * selectedPopulation);
  
  // Update acquisition cost calculations if we're on step 3
  if (selectedPopulation) {
    // Define the acquisition cost row update function
    const updateAcquisitionCostRow = (index, productA, productB) => {
      // Get the current and potential usage inputs
      const currentUsageInput = document.querySelector(`.step3-currentUsage-${index}`);
      const potentialUsageInput = document.querySelector(`.step3-potentialUsage-${index}`);
      
      // Get the cost display elements
      const cost1Element = document.querySelector(`.step3-cost1-${index}`);
      const cost2Element = document.querySelector(`.step3-cost2-${index}`);
      
      // Get the usage values
      const currentUsage = parseFloat(currentUsageInput?.value || 0);
      const potentialUsage = parseFloat(potentialUsageInput?.value || 0);
      
      // Calculate patient numbers
      const patientNumber1 = (currentUsage / 100) * selectedPopulation;
      const patientNumber2 = (potentialUsage / 100) * selectedPopulation;
      
      // Calculate average cost per usage
      let avgCostPerUsage1, avgCostPerUsage2;
      
      if (productB) {
        // For paired products
        avgCostPerUsage1 = productA.costPerUsage + productB.costPerUsage;
        avgCostPerUsage2 = productA.costPerUsage + productB.costPerUsage;
      } else {
        // For single product (3A)
        avgCostPerUsage1 = productA.costPerUsage;
        avgCostPerUsage2 = productA.costPerUsage;
      }
      
      // Calculate acquisition costs
      const acquisitionCost1 = avgCostPerUsage1 * patientNumber1;
      const acquisitionCost2 = avgCostPerUsage2 * patientNumber2;
      
      // Update the DOM
      if (cost1Element) cost1Element.textContent = formatCurrency(acquisitionCost1);
      if (cost2Element) cost2Element.textContent = formatCurrency(acquisitionCost2);
    };
    
    // Update the acquisition cost table
    // 1. Abrocitinib (1A, 1B)
    updateAcquisitionCostRow(0, products[0], products[1]);
    
    // 2. Baricitinib (2A, 2B)
    updateAcquisitionCostRow(1, products[2], products[3]);
    
    // 3. Dupilumab (3A)
    updateAcquisitionCostRow(2, products[4]);
    
    // 4. Lebrikizumab (4A, 4B)
    updateAcquisitionCostRow(3, products[5], products[6]);
    
    // 5. Tralokinumab (5A, 5B)
    updateAcquisitionCostRow(4, products[7], products[8]);
    
    // 6. Upadacitinib (6A, 6B)
    updateAcquisitionCostRow(5, products[9], products[10]);
  }
}

document.addEventListener("input", calculateAllCosts);

// Setup dropdown to toggle visibility on click
const dropdownBtn = document.querySelector('.custom-dropdown .dropdown-btn');
dropdownBtn.addEventListener('click', () => {
  const dropdownContent = document.querySelector('.custom-dropdown .dropdown-content');
  dropdownContent.style.display = dropdownContent.style.display === 'block' ? 'none' : 'block';
});

// Add event listener to EASI dropdown options
const easiDropdown = document.querySelector('.custom-dropdown .dropdown-content');
easiDropdown.addEventListener('click', (e) => {
  if (e.target.classList.contains('option')) {
    const selectedText = e.target.textContent.trim();
    document.querySelector('.custom-dropdown .dropdown-btn span').textContent = selectedText;
    calculateAllCosts();
    // Hide dropdown after selection
    easiDropdown.style.display = 'none';
  }
});

function linkComplementaryInputs() {
  const usageInputs = document.querySelectorAll(".usage-input");

  usageInputs.forEach((input) => {
    input.addEventListener("input", (e) => {
      const productId = e.target.dataset.product;
      const value = parseFloat(e.target.value) || 0;

      // Ensure the value is within bounds
      if (value < 0) {
        e.target.value = 0;
        return;
      }
      if (value > 100) {
        e.target.value = 100;
        return;
      }

      // Find complementary product
      const complementaryProductId = findComplementaryProduct(productId);
      if (complementaryProductId) {
        const complementaryInput = document.querySelector(`.usage-input[data-product="${complementaryProductId}"]`);
        if (complementaryInput) {
          complementaryInput.value = 100 - value; // Ensure the sum is 100
        }
      }

      // Trigger recalculations
      calculateAllCosts();
    });
  });
}

function findComplementaryProduct(productId) {
  const complementaryPairs = {
    "1A": "1B",
    "1B": "1A",
    "2A": "2B",
    "2B": "2A",
    "4A": "4B",
    "4B": "4A",
    "5A": "5B",
    "5B": "5A",
    "6A": "6B",
    "6B": "6A",
  };

  return complementaryPairs[productId] || null;
}

// Add the new dropdown option for step3
function addAcquisitionCostDropdownOption() {
  const dropdownContent = document.querySelector(
    ".custom-dropdown .dropdown-content"
  );
  const acquisitionOption = createElement(
    "div",
    { class: "option" },
    "<span>Acquisition Cost</span>"
  );
  dropdownContent.appendChild(acquisitionOption);
}

// Call the functions to create the table and add the dropdown option
createAcquisitionCostTable();
addAcquisitionCostDropdownOption();

createInitialTable();
createCalcTable();
createAveragesTable();


