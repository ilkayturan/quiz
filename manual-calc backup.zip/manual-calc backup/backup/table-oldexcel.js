const products = [
  {
    productId: "1A",
    productName: "Abrocitinib 200 mg (28 tablets)",
    calcProductName: "Abrocitinib 200 mg",
    initialCost: 0,
    cost1Multiplier: 4,
    cost2Multiplier: 13,
    percentageInput: 0,
    calculateCost1: (initialCost, cost1Multiplier) => initialCost * cost1Multiplier,
    calculateCost2: (initialCost, cost2Multiplier, cost1) => initialCost * cost2Multiplier,
    calculateUsage: (cost2, percentageInput) => cost2 * (percentageInput / 100),
  },
  {
    productId: "1B",
    productName: "Abrocitinib 100 mg (28 tablets)",
    calcProductName: "Abrocitinib 100 mg",
    initialCost: 0,
    cost1Multiplier: 4,
    cost2Multiplier: 13,
    percentageInput: 0,
    calculateCost1: (initialCost, cost1Multiplier) => initialCost * cost1Multiplier,
    calculateCost2: (initialCost, cost2Multiplier, cost1) => initialCost * cost2Multiplier,
    calculateUsage: (cost2, percentageInput) => cost2 * (percentageInput / 100),
  },
  {
    productId: "3A",
    productName: "Dupilumab 300 mg (2 pre-filled pens or syringes)",
    calcProductName: "Dupilumab 300 mg",
    initialCost: 0,
    cost1Multiplier: 4.5,
    cost2Multiplier: 9,
    percentageInput: 0,
    calculateCost1: (initialCost, cost1Multiplier) => initialCost * cost1Multiplier,
    calculateCost2: (initialCost, cost2Multiplier, cost1) => (initialCost * cost2Multiplier) + cost1,
    calculateUsage: (cost2, percentageInput) => cost2 * (percentageInput / 100),
  },
  {
    productId: "6B",
    productName: "Upadacitinib 30 mg (28 tablets)",
    calcProductName: "Upadacitinib 30 mg",
    initialCost: 0,
    cost1Multiplier: 4,
    cost2Multiplier: 13,
    percentageInput: 0,
    calculateCost1: (initialCost, cost1Multiplier) => initialCost * cost1Multiplier,
    calculateCost2: (initialCost, cost2Multiplier, cost1) => initialCost * cost2Multiplier,
    calculateUsage: (cost2, percentageInput) => cost2 * (percentageInput / 100),
  },
  {
    productId: "6A",
    productName: "Upadacitinib 15 mg (28 tablets)",
    calcProductName: "Upadacitinib 15 mg",
    initialCost: 0,
    cost1Multiplier: 4,
    cost2Multiplier: 13,
    percentageInput: 0,
    calculateCost1: (initialCost, cost1Multiplier) => initialCost * cost1Multiplier,
    calculateCost2: (initialCost, cost2Multiplier, cost1) => initialCost * cost2Multiplier,
    calculateUsage: (cost2, percentageInput) => cost2 * (percentageInput / 100),
  },
  {
    productId: "2A",
    productName: "Baricitinib 2 mg (28 tablets)",
    calcProductName: "Baricitinib 2 mg",
    initialCost: 0,
    cost1Multiplier: 4,
    cost2Multiplier: 13,
    percentageInput: 0,
    calculateCost1: (initialCost, cost1Multiplier) => initialCost * cost1Multiplier,
    calculateCost2: (initialCost, cost2Multiplier, cost1) => initialCost * cost2Multiplier,
    calculateUsage: (cost2, percentageInput) => cost2 * (percentageInput / 100),
  },
  {
    productId: "2B",
    productName: "Baricitinib 4 mg (28 tablets)",
    calcProductName: "Baricitinib 4 mg",
    initialCost: 0,
    cost1Multiplier: 4,
    cost2Multiplier: 13,
    percentageInput: 0,
    calculateCost1: (initialCost, cost1Multiplier) => initialCost * cost1Multiplier,
    calculateCost2: (initialCost, cost2Multiplier, cost1) => initialCost * cost2Multiplier,
    calculateUsage: (cost2, percentageInput) => cost2 * (percentageInput / 100),
  },
  {
    productId: "5A",
    productName: "Tralkinumab 300mg 2W",
    calcProductName: "Tralokinumab 300 mg 2W",
    initialCost: 0,
    cost1Multiplier: 4.5,
    cost2Multiplier: 9,
    percentageInput: 0,
    calculateCost1: (initialCost, cost1Multiplier) => initialCost * cost1Multiplier,
    calculateCost2: (initialCost, cost2Multiplier, cost1) => initialCost * cost2Multiplier,
    calculateUsage: (cost2, percentageInput) => cost2 * (percentageInput / 100),
  },
  {
    productId: "5B",
    productName: "Tralkinumab 300mg 4W",
    calcProductName: "Tralokinumab 300 mg 4W",
    initialCost: 0,
    cost1Multiplier: 4.5,
    cost2Multiplier: 4.5,
    percentageInput: 0,
    calculateCost1: (initialCost, cost1Multiplier) => initialCost * cost1Multiplier,
    calculateCost2: (initialCost, cost2Multiplier, cost1) => initialCost * cost2Multiplier,
    calculateUsage: (cost2, percentageInput) => cost2 * (percentageInput / 100),
  },
  {
    productId: "4A",
    productName: "Lebrikizumab 250 mg (2 pre-filled pens or syringes)",
    calcProductName: "Lebrikizumab 250 mg 2W",
    initialCost: 0,
    cost1Multiplier: 5,
    cost2Multiplier: 9,
    percentageInput: 0,
    calculateCost1: (initialCost, cost1Multiplier) => initialCost * cost1Multiplier,
    calculateCost2: (initialCost, cost2Multiplier, cost1) => (initialCost * cost2Multiplier) + cost1,
    calculateUsage: (cost2, percentageInput) => cost2 * (percentageInput / 100),
  },
  {
    productId: "4B",
    productName: "Lebrikizumab 250 mg (4 pre-filled pens or syringes)",
    calcProductName: "Lebrikizumab 250 mg 4W",
    initialCost: 0,
    cost1Multiplier: 5,
    cost2Multiplier: 4.5,
    percentageInput: 0,
    calculateCost1: (initialCost, cost1Multiplier) => initialCost * cost1Multiplier,
    calculateCost2: (initialCost, cost2Multiplier, cost1) => (initialCost * cost2Multiplier) + cost1,
    calculateUsage: (cost2, percentageInput) => cost2 * (percentageInput / 100),
  },
];

function formatCurrency(amount) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'EUR' }).format(amount);
}

function createTable(containerSelector, headers, rows) {
  const container = document.querySelector(containerSelector);
  const headerRow = document.createElement("div");
  headerRow.className = "row";
  headers.forEach((header) => {
    const headerCell = document.createElement("div");
    headerCell.className = "cell";
    headerCell.innerHTML = header;
    headerRow.appendChild(headerCell);
  });
  container.appendChild(headerRow);

  rows.forEach((rowData) => {
    const row = document.createElement("div");
    row.className = "row";
    row.id = `row-${container.children.length}`;
    rowData.forEach((cellData) => {
      const cell = document.createElement("div");
      cell.className = "cell";
      if (typeof cellData === "string") {
        cell.textContent = cellData;
      } else {
        cell.appendChild(cellData);
      }
      row.appendChild(cell);
    });
    container.appendChild(row);
  });
}

function createInitialTable() {
  const headers = [
    "<strong>Treatment</strong>",
    "<p><strong>Enter the price you pay for one pack of treatment (£)</strong></p> <p>All cost fields must be filled</p>",
  ];
  const rows = products.map((product) => [
    product.productName,
    (() => {
      const container = document.createElement("div");
      container.className = "input-container";
      const span = document.createElement("span");
      span.className = "currency";
      span.textContent = "€";
      const input = document.createElement("input");
      input.type = "number";
      input.placeholder = 0;
      input.dataset.product = product.productId;
      input.className = "initial-cost";
      container.appendChild(span);
      container.appendChild(input);
      return container;
    })(),
  ]);
  createTable(".initial-table", headers, rows);
}

function createCalcTable() {
  const headers = [
    "<strong>Treatment</strong>",
    "Initial Cost",
    "Cost 2",
    "Percentage",
  ];
  const rows = products.map((product) => [
    product.calcProductName,
    (() => {
      const cell = document.createElement("div");
      cell.dataset.product = product.productId;
      cell.className = "initial-cost-display";
      cell.textContent = formatCurrency(0);
      return cell;
    })(),
    (() => {
      const cell = document.createElement("div");
      cell.dataset.product = product.productId;
      cell.className = "cost2";
      cell.textContent = formatCurrency(0);
      return cell;
    })(),
    (() => {
      const container = document.createElement("div");
      container.className = "input-container";
      const span = document.createElement("span");
      span.className = "percentage";
      span.textContent = "%";
      const input = document.createElement("input");
      input.type = "number";
      input.placeholder = 0;
      input.dataset.product = product.productId;
      input.className = "percentage-input";
      container.appendChild(span);
      container.appendChild(input);
      return container;
    })(),
  ]);
  createTable(".calc-table", headers, rows);
}



function createAveragesTable() {
  const headers = ["Result", "Calculation"];
  const rows = [
    [
      (() => {
        const cell = document.createElement("div");
        cell.id = "product1A-product1B-usage";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
      (() => {
        const cell = document.createElement("div");
        cell.id = "product1A-product1B-calculation";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
    ],
    [
      (() => {
        const cell = document.createElement("div");
        cell.id = "product3A-usage";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
      (() => {
        const cell = document.createElement("div");
        cell.id = "product3A-calculation";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
    ],
    [
      (() => {
        const cell = document.createElement("div");
        cell.id = "product6A-product6B-usage";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
      (() => {
        const cell = document.createElement("div");
        cell.id = "product6A-product6B-calculation";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
    ],
    [
      (() => {
        const cell = document.createElement("div");
        cell.id = "product2A-product2B-usage";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
      (() => {
        const cell = document.createElement("div");
        cell.id = "product2A-product2B-calculation";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
    ],
    [
      (() => {
        const cell = document.createElement("div");
        cell.id = "product5A-product5B-usage";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
      (() => {
        const cell = document.createElement("div");
        cell.id = "product5A-product5B-calculation";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
    ],
    [
      (() => {
        const cell = document.createElement("div");
        cell.id = "product4A-product4B-usage";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
      (() => {
        const cell = document.createElement("div");
        cell.id = "product4A-product4B-calculation";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
    ],
    
  ];
  createTable(".averages", headers, rows);
}

function updateCalculations() {
  products.forEach((product) => {
    const initialCost =
      parseFloat(
        document.querySelector(
          `.initial-cost[data-product="${product.productId}"]`
        ).value
      ) || 0;
    const percentageInput =
      parseFloat(
        document.querySelector(
          `.percentage-input[data-product="${product.productId}"]`
        ).value
      ) || 0;

    product.initialCost = initialCost;
    product.percentageInput = percentageInput;

    const cost1 = product.calculateCost1(initialCost, product.cost1Multiplier);
    const cost2 = product.calculateCost2(
      initialCost,
      product.cost2Multiplier,
      cost1
    );
    const usage = product.calculateUsage(cost2, percentageInput);

    document.querySelector(`.initial-cost-display[data-product="${product.productId}"]`).textContent = formatCurrency(initialCost);
    document.querySelector(`.cost2[data-product="${product.productId}"]`).textContent = formatCurrency(cost2);

    product.cost1 = cost1;
    product.cost2 = cost2;
    product.usage = usage;
  });

  const product1A = products[0];
  const product1B = products[1];
  const product3A = products[2];
  const product6B = products[3];
  const product6A = products[4];
  const product2A = products[5];
  const product2B = products[6];
  const product5A = products[7];
  const product5B = products[8];
  const product4A = products[9];
  const product4B = products[10];

  const product1AProduct1BUsage = (product1A.usage + product1B.usage).toFixed(2);
  document.getElementById("product1A-product1B-usage").textContent = formatCurrency(product1AProduct1BUsage);

  const product1AProduct1BCalculation = formatCurrency((parseFloat(product1AProduct1BUsage) * 5).toFixed(2));
  document.getElementById("product1A-product1B-calculation").textContent = product1AProduct1BCalculation;

  const product6AProduct6BUsage = (product6A.usage + product6B.usage).toFixed(2);
  document.getElementById("product6A-product6B-usage").textContent = formatCurrency(product6AProduct6BUsage);

  const product6AProduct6BCalculation = formatCurrency((parseFloat(product6AProduct6BUsage) * 5).toFixed(2));
  document.getElementById("product6A-product6B-calculation").textContent = product6AProduct6BCalculation;

  const product3AUsage = product3A.usage.toFixed(2);
  document.getElementById("product3A-usage").textContent = formatCurrency(product3AUsage);

  const product3ACalculation = formatCurrency((parseFloat(product3AUsage) * 5).toFixed(2));
  document.getElementById("product3A-calculation").textContent = product3ACalculation;

  const product2AProduct2BUsage = (product2A.usage + product2B.usage).toFixed(2);
  document.getElementById("product2A-product2B-usage").textContent = formatCurrency(product2AProduct2BUsage);
  
  const product2ACost = ((product2A.percentageInput / 100) * product2A.initialCost) * 52;
  const product2BCost = ((product2B.percentageInput / 100) * product2B.initialCost) * 52;
  const totalCost = product2ACost + product2BCost + parseFloat(product2AProduct2BUsage);
  const product2AProduct2BCalculation = formatCurrency(totalCost.toFixed(2));
  document.getElementById("product2A-product2B-calculation").textContent = product2AProduct2BCalculation;

  const product5AProduct5BUsage = (product5A.usage + product5B.usage).toFixed(2);
  document.getElementById("product5A-product5B-usage").textContent = formatCurrency(product5AProduct5BUsage);

  const product5AProduct5BCalculation = formatCurrency((parseFloat(product5AProduct5BUsage) * 5).toFixed(2));
  document.getElementById("product5A-product5B-calculation").textContent = product5AProduct5BCalculation;

  const product4AProduct4BUsage = (product4A.usage + product4B.usage).toFixed(2);
  document.getElementById("product4A-product4B-usage").textContent = formatCurrency(product4AProduct4BUsage);

  const product4AProduct4BCalculation = formatCurrency(((parseFloat(product4AProduct4BUsage) + product4A.cost1) * 5).toFixed(2));
  document.getElementById("product4A-product4B-calculation").textContent = product4AProduct4BCalculation;
}

document.addEventListener("input", updateCalculations);

createInitialTable();
createCalcTable();
createAveragesTable();
