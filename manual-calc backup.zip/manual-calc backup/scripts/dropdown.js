const container = document.getElementById("dropdownContainer");
const resultDiv = document.getElementById("populationResult");
const cities = {
  National: [
    { name: 'England', population: 541 },
    { name: 'Wales', population: 543 },
    { name: 'Northern Ireland', population: 643 },
  ],
  EnglandICB: [
    { name: 'England', population: 64 },
    { name: 'Wales', population: 543 },
    { name: 'Northern Ireland', population: 23 },
  ]
  ,NHSERegions: [
    { name: 'England', population: 43 },
    { name: 'Wales', population: 64 },
    { name: 'Northern Ireland', population: 214 },
  ],
  WalesHealthBoards: [
    { name: 'England', population: 134 },
    { name: 'Wales', population: 111 },
    { name: 'Northern Ireland', population: 521 },
  ],
  NIHealthandSocialCareTrusts: [
    { name: 'England', population: 123 },
    { name: 'Wales', population: 321 },
    { name: 'Northern Ireland', population: 320 },
  ],
  LAWales: [
    { name: 'England', population: 423 },
    { name: 'Wales', population: 21 },
    { name: 'Northern Ireland', population: 432 },
  ],
  LANI: [
    { name: 'England', population: 32 },
    { name: 'Wales', population: 12 },
    { name: 'Northern Ireland', population: 19 },
  ],
  LAEngland: [
    { name: 'England', population: 6 },
    { name: 'Wales', population: 5 },
    { name: 'Northern Ireland', population: 4 },
  ],
  EnglandCCGs: [
    { name: 'England', population: 3 },
    { name: 'Wales', population: 2 },
    { name: 'Northern Ireland', population: 1 },
  ]
};

function createDropdown(id, placeholder, options = []) {
  const dropdown = document.createElement('div');
  dropdown.classList.add('dropdown');
  dropdown.id = id;

  const selected = document.createElement('div');
  selected.classList.add('selected');
  selected.innerText = placeholder;

  const optionsDiv = document.createElement('div');
  optionsDiv.classList.add('options');

  options.forEach(option => {
    const optionElement = document.createElement('div');
    optionElement.classList.add('option');
    optionElement.dataset.value = option.value;
    optionElement.textContent = option.label;
    optionsDiv.appendChild(optionElement);
  });

  dropdown.appendChild(selected);
  dropdown.appendChild(optionsDiv);
  container.appendChild(dropdown);

  return { dropdown, selected, optionsDiv };
}

function setupDropdown(dropdown) {
  const selected = dropdown.querySelector('.selected');
  const options = dropdown.querySelector('.options');

  selected.addEventListener('click', () => {
    options.style.display = options.style.display === 'block' ? 'none' : 'block';
  });

  document.addEventListener('click', (e) => {
    if (!dropdown.contains(e.target)) {
      options.style.display = 'none';
    }
  });

  options.addEventListener('click', (e) => {
    if (e.target.classList.contains('option')) {
      selected.innerText = e.target.textContent;
      selected.dataset.value = e.target.dataset.value;
      options.style.display = 'none';
    }
  });
}

const { dropdown: regionDropdown, selected: regionSelected, optionsDiv: regionOptions } = createDropdown(
  "regionDropdown",
  "Select Region",
  [
    { label: 'National', value: 'National' },
    { label: 'England ICB', value: 'EnglandICB' },
    { label: 'NHSE Regions', value: 'NHSERegions' },
    { label: 'Wales Health Boards', value: 'WalesHealthBoards' },
    { label: 'NI Health and Social Care Trusts', value: 'NIHealthandSocialCareTrusts' },
    { label: 'LA Wales', value: 'LAWales' },
    { label: 'LA NI', value: 'LANI' },
    { label: 'LA England', value: 'LAEngland' },
    { label: 'England CCGs', value: 'EnglandCCGs' },
  ]
);

const { dropdown: cityDropdown, selected: citySelected, optionsDiv: cityOptions } = createDropdown(
  "cityDropdown",
  "Select City"
);

let selectedPopulation = null; // Variable to store the selected population

setupDropdown(regionDropdown);
setupDropdown(cityDropdown);

regionOptions.addEventListener('click', (e) => {
  if (e.target.classList.contains('option')) {
    const selectedRegion = e.target.dataset.value;
    citySelected.textContent = 'Select City';
    cityOptions.innerHTML = '';
    resultDiv.innerHTML = '&nbsp;';

    if (cities[selectedRegion]) {
      cities[selectedRegion].forEach(city => {
        const cityDiv = document.createElement('div');
        cityDiv.classList.add("option");
        cityDiv.dataset.value = city.population;
        cityDiv.textContent = city.name;
        cityOptions.appendChild(cityDiv);
      });

      cityOptions.style.display = 'block';

      // Automatically select the first option from the second dropdown
      const firstCityOption = cityOptions.querySelector('.option');
      if (firstCityOption) {
        citySelected.textContent = firstCityOption.textContent;
        citySelected.dataset.value = firstCityOption.dataset.value;
        resultDiv.textContent = `${firstCityOption.dataset.value}`;
        selectedPopulation = firstCityOption.dataset.value; // Update the selected population
        console.log(`Selected population: ${firstCityOption.dataset.value}`);
      }
    }
  }
});

cityOptions.addEventListener('click', (e) => {
  if (e.target.classList.contains('option')) {
    const population = e.target.dataset.value;
    resultDiv.textContent = `${population}`;
    selectedPopulation = population; // Update the selected population
    console.log(`Selected population: ${population}`);
  }
});


console.log(`Latest selected population: ${selectedPopulation}`);