const products = [
  {
    productId: "1A",
    productName: "Abrocitinib 100 mg (28 tablets)",
    calcProductName: "Abrocitinib 100 mg",
    initialCost: 0,
    multiplier: 13,
    percentageInput: 0,
    calculateCostPerYear: (initialCost, multiplier) => initialCost * multiplier,
    calculateUsage: (costPY, percentageInput) => costPY * (percentageInput / 100),
  },
  {
    productId: "1B",
    productName: "Abrocitinib 200 mg (28 tablets)",
    calcProductName: "Abrocitinib 200 mg",
    initialCost: 0,
    multiplier: 13,
    percentageInput: 0,
    calculateCostPerYear: (initialCost, multiplier) => initialCost * multiplier,
    calculateUsage: (costPY, percentageInput) => costPY * (percentageInput / 100),
  },
  {
    productId: "2A",
    productName: "Baricitinib 2 mg (28 tablets)",
    calcProductName: "Baricitinib 2 mg",
    initialCost: 0,
    multiplier: 13,
    percentageInput: 0,
    calculateCostPerYear: (initialCost, multiplier) => initialCost * multiplier,
    calculateUsage: (costPY, percentageInput) => costPY * (percentageInput / 100),
  },
  {
    productId: "2B",
    productName: "Baricitinib 4 mg (28 tablets)",
    calcProductName: "Baricitinib 4 mg",
    initialCost: 0,
    multiplier: 13,
    percentageInput: 0,
    calculateCostPerYear: (initialCost, multiplier) => initialCost * multiplier,
    calculateUsage: (costPY, percentageInput) => costPY * (percentageInput / 100),
  },
  {
    productId: "3A",
    productName: "Dupilumab 300 mg (2 pre-filled pens or syringes)",
    calcProductName: "Dupilumab 300 mg",
    initialCost: 0,
    multiplier: 13.5,
    percentageInput: 0,
    calculateCostPerYear: (initialCost, multiplier) => initialCost * multiplier,
    calculateUsage: (costPY, percentageInput) => costPY * (percentageInput / 100),
  },
  {
    productId: "4A",
    productName: "Lebrikizumab 250 mg (2 pre-filled pens or syringes)",
    calcProductName: "Lebrikizumab 250 mg 2W",
    initialCost: 0,
    multiplier: 9.5,
    percentageInput: 0,
    calculateCostPerYear: (initialCost, multiplier) => initialCost * multiplier,
    calculateUsage: (costPY, percentageInput) => costPY * (percentageInput / 100),
  },
  {
    productId: "4B",
    productName: "Lebrikizumab 250 mg (4 pre-filled pens or syringes)",
    calcProductName: "Lebrikizumab 250 mg 4W",
    initialCost: 0,
    multiplier: 10.5,
    percentageInput: 0,
    calculateCostPerYear: (initialCost, multiplier) => initialCost * multiplier,
    calculateUsage: (costPY, percentageInput) => costPY * (percentageInput / 100),
  },
  {
    productId: "5A",
    productName: "Tralkinumab 300mg 2W",
    calcProductName: "Tralokinumab 300 mg 2W",
    initialCost: 0,
    multiplier: 9,
    percentageInput: 0,
    calculateCostPerYear: (initialCost, multiplier) => initialCost * multiplier,
    calculateUsage: (costPY, percentageInput) => costPY * (percentageInput / 100),
  },
  {
    productId: "5B",
    productName: "Tralkinumab 300mg 4W",
    calcProductName: "Tralokinumab 300 mg 4W",
    initialCost: 0,
    multiplier: 13.5,
    percentageInput: 0,
    calculateCostPerYear: (initialCost, multiplier) => initialCost * multiplier,
    calculateUsage: (costPY, percentageInput) => costPY * (percentageInput / 100),
  },
  {
    productId: "6A",
    productName: "Upadacitinib 15 mg (28 tablets)",
    calcProductName: "Upadacitinib 15 mg",
    initialCost: 0,
    multiplier: 13,
    percentageInput: 0,
    calculateCostPerYear: (initialCost, multiplier) => initialCost * multiplier,
    calculateUsage: (costPY, percentageInput) => costPY * (percentageInput / 100),
  },
  {
    productId: "6B",
    productName: "Upadacitinib 30 mg (28 tablets)",
    calcProductName: "Upadacitinib 30 mg",
    initialCost: 0,
    multiplier: 13,
    percentageInput: 0,
    calculateCostPerYear: (initialCost, multiplier) => initialCost * multiplier,
    calculateUsage: (costPY, percentageInput) => costPY * (percentageInput / 100),
  },
];


function formatCurrency(amount) {
  return new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format(amount);
}

function createTable(containerSelector, headers, rows) {
  const container = document.querySelector(containerSelector);
  const headerRow = document.createElement("div");
  headerRow.className = "row";
  headers.forEach((header) => {
    const headerCell = document.createElement("div");
    headerCell.className = "cell";
    headerCell.innerHTML = header;
    headerRow.appendChild(headerCell);
  });
  container.appendChild(headerRow);

  rows.forEach((rowData) => {
    const row = document.createElement("div");
    row.className = "row";
    row.id = `row-${container.children.length}`;
    rowData.forEach((cellData) => {
      const cell = document.createElement("div");
      cell.className = "cell";
      if (typeof cellData === "string") {
        cell.textContent = cellData;
      } else {
        cell.appendChild(cellData);
      }
      row.appendChild(cell);
    });
    container.appendChild(row);
  });
}

function createInitialTable() {
  const headers = [
    "<strong>Treatment</strong>",
    "<p><strong>Enter the price you pay for one pack of treatment (£)</strong></p> <p>All cost fields must be filled</p>",
  ];
  const rows = products.map((product) => [
    product.productName,
    (() => {
      const container = document.createElement("div");
      container.className = "input-container";
      const span = document.createElement("span");
      span.className = "currency";
      span.textContent = "£";
      const input = document.createElement("input");
      input.type = "number";
      input.placeholder = 0;
      input.dataset.product = product.productId;
      input.className = "initial-cost";
      container.appendChild(span);
      container.appendChild(input);
      return container;
    })(),
  ]);
  createTable(".initial-table", headers, rows);
}

function createCalcTable() {
  const headers = [
    "<strong>Treatment</strong>",
    "Cost<br>per patient",
    "Cost<br>per responding population",
    "Percentage",
  ];
  const rows = products.map((product) => [
    product.calcProductName,
    (() => {
      const cell = document.createElement("div");
      cell.dataset.product = product.productId;
      cell.className = "cost-per-patient";
      cell.textContent = formatCurrency(0);
      return cell;
    })(),
    (() => {
      const cell = document.createElement("div");
      cell.dataset.product = product.productId;
      cell.className = "cost-per-responding-population";
      cell.textContent = formatCurrency(0);
      return cell;
    })(),
    (() => {
      const container = document.createElement("div");
      container.className = "input-container";
      const span = document.createElement("span");
      span.className = "percentage";
      span.textContent = "%";
      const input = document.createElement("input");
      input.type = "number";
      input.placeholder = 0;
      input.dataset.product = product.productId;
      input.className = "percentage-input";
      container.appendChild(span);
      container.appendChild(input);
      return container;
    })(),
  ]);
  createTable(".calc-table", headers, rows);
}

function createAveragesTable() {
  const headers = ["Result", "Calculation"];
  const rows = [
    [
      (() => {
        const cell = document.createElement("div");
        cell.id = "product1A-product1B-perPatient";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
      (() => {
        const cell = document.createElement("div");
        cell.id = "product1A-product1B-calculation";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
    ],
    [
      (() => {
        const cell = document.createElement("div");
        cell.id = "product2A-product2B-perPatient";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
      (() => {
        const cell = document.createElement("div");
        cell.id = "product2A-product2B-calculation";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
    ],
    [
      (() => {
        const cell = document.createElement("div");
        cell.id = "product3A-perPatient";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
      (() => {
        const cell = document.createElement("div");
        cell.id = "product3A-calculation";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
    ],
    [
      (() => {
        const cell = document.createElement("div");
        cell.id = "product4A-product4B-perPatient";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
      (() => {
        const cell = document.createElement("div");
        cell.id = "product4A-product4B-calculation";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
    ],
    [
      (() => {
        const cell = document.createElement("div");
        cell.id = "product5A-product5B-perPatient";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
      (() => {
        const cell = document.createElement("div");
        cell.id = "product5A-product5B-calculation";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
    ],
    [
      (() => {
        const cell = document.createElement("div");
        cell.id = "product6A-product6B-perPatient";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
      (() => {
        const cell = document.createElement("div");
        cell.id = "product6A-product6B-calculation";
        cell.textContent = formatCurrency(0);
        return cell;
      })(),
    ],
  ];
  createTable(".averages", headers, rows);
}

function updateCalculations() {
  products.forEach((product) => {
    const initialCost =
      parseFloat(
        document.querySelector(
          `.initial-cost[data-product="${product.productId}"]`
        ).value
      ) || 0;
    const percentageInput =
      parseFloat(
        document.querySelector(
          `.percentage-input[data-product="${product.productId}"]`
        ).value
      ) || 0;

    product.initialCost = initialCost;
    product.percentageInput = percentageInput;

    const costPY = product.calculateCostPerYear(initialCost, product.multiplier);
    const perPatient = product.calculateUsage(costPY, percentageInput);

    document.querySelector(`.cost-per-patient[data-product="${product.productId}"]`).textContent = formatCurrency(initialCost);
    document.querySelector(`.cost-per-responding-population[data-product="${product.productId}"]`).textContent = formatCurrency(costPY);

    product.costPY = costPY;
    product.perPatient = perPatient;
  });

  const product1A = products[0];
  const product1B = products[1];
  const product2A = products[2];
  const product2B = products[3];
  const product3A = products[4];
  const product4A = products[5];
  const product4B = products[6];
  const product5A = products[7];
  const product5B = products[8];
  const product6A = products[9];
  const product6B = products[10];

  const product1AProduct1BUsage = (product1A.perPatient + product1B.perPatient).toFixed(2);
  document.getElementById("product1A-product1B-perPatient").textContent = formatCurrency(product1AProduct1BUsage);

  const product1AProduct1BCalculation = formatCurrency((parseFloat(product1AProduct1BUsage) * 5).toFixed(2));
  document.getElementById("product1A-product1B-calculation").textContent = product1AProduct1BCalculation;

  const product2AProduct2BUsage = (product2A.perPatient + product2B.perPatient).toFixed(2);
  document.getElementById("product2A-product2B-perPatient").textContent = formatCurrency(product2AProduct2BUsage);
  
  const product2ACost = ((product2A.percentageInput / 100) * product2A.initialCost) * 52;
  const product2BCost = ((product2B.percentageInput / 100) * product2B.initialCost) * 52;
  const totalCost = product2ACost + product2BCost + parseFloat(product2AProduct2BUsage);
  const product2AProduct2BCalculation = formatCurrency(totalCost.toFixed(2));
  document.getElementById("product2A-product2B-calculation").textContent = product2AProduct2BCalculation;

  const product3AUsage = product3A.perPatient.toFixed(2);
  document.getElementById("product3A-perPatient").textContent = formatCurrency(product3AUsage);

  const product3ACalculation = formatCurrency((parseFloat(product3AUsage) * 5).toFixed(2));
  document.getElementById("product3A-calculation").textContent = product3ACalculation;

  const product4AProduct4BUsage = (product4A.perPatient + product4B.perPatient).toFixed(2);
  document.getElementById("product4A-product4B-perPatient").textContent = formatCurrency(product4AProduct4BUsage);

  const product4AProduct4BCalculation = formatCurrency(((parseFloat(product4AProduct4BUsage) + product4A.costPY) * 5).toFixed(2));
  document.getElementById("product4A-product4B-calculation").textContent = product4AProduct4BCalculation;

  const product5AProduct5BUsage = (product5A.perPatient + product5B.perPatient).toFixed(2);
  document.getElementById("product5A-product5B-perPatient").textContent = formatCurrency(product5AProduct5BUsage);

  const product5AProduct5BCalculation = formatCurrency((parseFloat(product5AProduct5BUsage) * 5).toFixed(2));
  document.getElementById("product5A-product5B-calculation").textContent = product5AProduct5BCalculation;

  const product6AProduct6BUsage = (product6A.perPatient + product6B.perPatient).toFixed(2);
  document.getElementById("product6A-product6B-perPatient").textContent = formatCurrency(product6AProduct6BUsage);

  const product6AProduct6BCalculation = formatCurrency((parseFloat(product6AProduct6BUsage) * 5).toFixed(2));
  document.getElementById("product6A-product6B-calculation").textContent = product6AProduct6BCalculation;

}

document.addEventListener("input", updateCalculations);

createInitialTable();
createCalcTable();
createAveragesTable();

document.querySelectorAll('.custom-dropdown').forEach(dropdown => {
  const button = dropdown.querySelector('.dropdown-btn');
  const content = dropdown.querySelector('.dropdown-content');

  button.addEventListener('click', (event) => {
    event.stopPropagation();
    document.querySelectorAll('.dropdown-content').forEach(c => {
      if (c !== content) c.style.display = 'none';
    });
    content.style.display = content.style.display === 'block' ? 'none' : 'block';
  });

  content.querySelectorAll('div').forEach(option => {
    option.addEventListener('click', () => {
      button.textContent = option.textContent;
      content.style.display = 'none';
    });
  });

  document.addEventListener('click', () => {
    content.style.display = 'none';
  });
});

const container = document.getElementById("dropdownContainer");
const resultDiv = document.getElementById("populationResult");
const cities = {
  National: [
    { name: 'England', population: 541 },
    { name: 'Wales', population: 543 },
    { name: 'Northern Ireland', population: 643 },
  ],
  EnglandICB: [
    { name: 'England', population: 64 },
    { name: 'Wales', population: 543 },
    { name: 'Northern Ireland', population: 23 },
  ],
  NHSERegions: [
    { name: 'England', population: 43 },
    { name: 'Wales', population: 64 },
    { name: 'Northern Ireland', population: 214 },
  ],
  WalesHealthBoards: [
    { name: 'England', population: 134 },
    { name: 'Wales', population: 111 },
    { name: 'Northern Ireland', population: 521 },
  ],
  NIHealthandSocialCareTrusts: [
    { name: 'England', population: 123 },
    { name: 'Wales', population: 321 },
    { name: 'Northern Ireland', population: 320 },
  ],
  LAWales: [
    { name: 'England', population: 423 },
    { name: 'Wales', population: 21 },
    { name: 'Northern Ireland', population: 432 },
  ],
  LANI: [
    { name: 'England', population: 32 },
    { name: 'Wales', population: 12 },
    { name: 'Northern Ireland', population: 19 },
  ],
  LAEngland: [
    { name: 'England', population: 6 },
    { name: 'Wales', population: 5 },
    { name: 'Northern Ireland', population: 4 },
  ],
  EnglandCCGs: [
    { name: 'England', population: 3 },
    { name: 'Wales', population: 2 },
    { name: 'Northern Ireland', population: 1 },
  ]
};

function createDropdown(id, placeholder, options = []) {
  const dropdown = document.createElement('div');
  dropdown.classList.add('dropdown');
  dropdown.id = id;

  const selected = document.createElement('div');
  selected.classList.add('selected');
  selected.innerText = placeholder;

  const optionsDiv = document.createElement('div');
  optionsDiv.classList.add('options');

  options.forEach(option => {
    const optionElement = document.createElement('div');
    optionElement.classList.add('option');
    optionElement.dataset.value = option.value;
    optionElement.textContent = option.label;
    optionsDiv.appendChild(optionElement);
  });

  dropdown.appendChild(selected);
  dropdown.appendChild(optionsDiv);
  container.appendChild(dropdown);

  return { dropdown, selected, optionsDiv };
}

function setupDropdown(dropdown) {
  const selected = dropdown.querySelector('.selected');
  const options = dropdown.querySelector('.options');

  selected.addEventListener('click', () => {
    options.style.display = options.style.display === 'block' ? 'none' : 'block';
  });

  document.addEventListener('click', (e) => {
    if (!dropdown.contains(e.target)) {
      options.style.display = 'none';
    }
  });

  options.addEventListener('click', (e) => {
    if (e.target.classList.contains('option')) {
      selected.innerText = e.target.textContent;
      selected.dataset.value = e.target.dataset.value;
      options.style.display = 'none';
    }
  });
}

const { dropdown: regionDropdown, selected: regionSelected, optionsDiv: regionOptions } = createDropdown(
  "regionDropdown",
  "Select Region",
  [
    { label: 'National', value: 'National' },
    { label: 'England ICB', value: 'EnglandICB' },
    { label: 'NHSE Regions', value: 'NHSERegions' },
    { label: 'Wales Health Boards', value: 'WalesHealthBoards' },
    { label: 'NI Health and Social Care Trusts', value: 'NIHealthandSocialCareTrusts' },
    { label: 'LA Wales', value: 'LAWales' },
    { label: 'LA NI', value: 'LANI' },
    { label: 'LA England', value: 'LAEngland' },
    { label: 'England CCGs', value: 'EnglandCCGs' },
  ]
);

const { dropdown: cityDropdown, selected: citySelected, optionsDiv: cityOptions } = createDropdown(
  "cityDropdown",
  "Select City"
);

let selectedPopulation = null; // Variable to store the selected population

setupDropdown(regionDropdown);
setupDropdown(cityDropdown);

regionOptions.addEventListener('click', (e) => {
  if (e.target.classList.contains('option')) {
    const selectedRegion = e.target.dataset.value;
    citySelected.textContent = 'Select City';
    cityOptions.innerHTML = '';
    resultDiv.innerHTML = '&nbsp;';

    if (cities[selectedRegion]) {
      cities[selectedRegion].forEach(city => {
        const cityDiv = document.createElement('div');
        cityDiv.classList.add("option");
        cityDiv.dataset.value = city.population;
        cityDiv.textContent = city.name;
        cityOptions.appendChild(cityDiv);
      });

      cityOptions.style.display = 'block';

      // Automatically select the first option from the second dropdown
      const firstCityOption = cityOptions.querySelector('.option');
      if (firstCityOption) {
        citySelected.textContent = firstCityOption.textContent;
        citySelected.dataset.value = firstCityOption.dataset.value;
        resultDiv.textContent = `${firstCityOption.dataset.value}`;
        selectedPopulation = firstCityOption.dataset.value; // Update the selected population
        console.log(`Selected population: ${firstCityOption.dataset.value}`);

        // Update the element with id "step2-population"
        const step2PopulationElement = document.getElementById('step2-population');
        const step3PopulationElement = document.getElementById('step3-population');
        [step2PopulationElement, step3PopulationElement].forEach(element => {
          if (element) {
            element.textContent = selectedPopulation;
          }
        });
      }
    }
  }
});

cityOptions.addEventListener('click', (e) => {
  if (e.target.classList.contains('option')) {
    const population = e.target.dataset.value;
    resultDiv.textContent = `${population}`;
    selectedPopulation = population; // Update the selected population

    // Update the element with id "step2-population"
    const step2PopulationElement = document.getElementById('step2-population');
    const step3PopulationElement = document.getElementById('step3-population');
    [step2PopulationElement, step3PopulationElement].forEach(element => {
      if (element) {
        element.textContent = selectedPopulation;
      }
    });
  }
});

// Add a new element for the message under the dropdown
const messageDiv = document.createElement('div');
messageDiv.id = 'populationMessage';
messageDiv.style.color = 'red';
messageDiv.style.fontSize = 'small';
messageDiv.style.display = 'none';
messageDiv.textContent = 'Please select the population';
container.prepend(messageDiv);

// Page transition and Step indicator logic
document.querySelectorAll('.next-step, .prev-step').forEach(button => {
  button.addEventListener('click', () => {
    if (button.classList.contains('next-step') && !selectedPopulation) {
      messageDiv.style.display = 'block'; // Show the message
      return;
    }
    messageDiv.style.display = 'none'; // Hide the message
    const currentStep = button.closest('.step-one, .step-two, .step-three');
    const targetStep = button.classList.contains('next-step') ? currentStep.nextElementSibling : currentStep.previousElementSibling;
    currentStep.classList.add('hide');
    targetStep.classList.remove('hide');
    updateStepIndicators();
  });
});

const steps = [document.getElementById('step1'), document.getElementById('step2'), document.getElementById('step3')];
const stepIndicators = [document.getElementById('step-indicator1'), document.getElementById('step-indicator2'), document.getElementById('step-indicator3')];
stepIndicators.forEach((indicator, index) => indicator.innerHTML = index + 1);

function updateStepIndicators() {
  const checkmarkSVG = `<svg class="checkmark" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"
      stroke-linejoin="round"></path>
  </svg>`;

  stepIndicators.forEach((indicator, index) => {
    if (!steps[index].classList.contains('hide')) {
      indicator.innerHTML = index + 1;
      indicator.classList.add('active-step');
    } else {
      indicator.innerHTML = index + 1;
      indicator.classList.remove('active-step');
    }

    // Add checkmark to all previous steps
    if (index < steps.findIndex(step => !step.classList.contains('hide'))) {
      indicator.innerHTML = checkmarkSVG;
      indicator.classList.add('active-step');
    }
  });
}

updateStepIndicators();

function createStepHeader(stepId) {
  const stepHeader = document.createElement('div');
  stepHeader.classList.add('step-header');

  const outcomeBox = document.createElement('div');
  outcomeBox.classList.add('outcome-box');

  const outcomeTitle = document.createElement('h3');
  outcomeTitle.classList.add('outcome-title');
  outcomeTitle.textContent = 'Cost per responder';

  const outcomePopulation = document.createElement('div');
  outcomePopulation.classList.add('outcome-population');
  outcomePopulation.textContent = 'All outputs are modelled over a 1-year time frame';

  const calcMethodLink = document.createElement('a');
  calcMethodLink.href = '#';
  calcMethodLink.classList.add('calc-method-link');
  calcMethodLink.textContent = 'Methodology';

  const outcomeSelect = document.createElement('div');
  outcomeSelect.classList.add('outcome-select');

  const dropdownGroup = document.createElement('div');
  dropdownGroup.classList.add('dropdown-group');

  const dropdownContainer = document.createElement('div');
  dropdownContainer.classList.add('dropdown-container');

  const dropdownLabel = document.createElement('p');
  dropdownLabel.innerHTML = '<strong>Select an AD outcome&nbsp;</strong>';

  const customDropdown = document.createElement('div');
  customDropdown.classList.add('custom-dropdown');

  const dropdownBtn = document.createElement('button');
  dropdownBtn.type = 'button';
  dropdownBtn.classList.add('dropdown-btn');
  dropdownBtn.innerHTML = '<span>EASI 50</span>';

  const dropdownContent = document.createElement('div');
  dropdownContent.classList.add('dropdown-content');

  const outcomes = [
    { label: 'EASI 50', value: 0.5 },
    { label: 'EASI 75', value: 0.75 },
    { label: 'EASI 90', value: 0.9 },
    { label: 'IGA 0/1', value: 1.0 }
  ];

  outcomes.forEach(outcome => {
    const outcomeDiv = document.createElement('div');
    outcomeDiv.dataset.value = outcome.value;
    outcomeDiv.innerHTML = `<span>${outcome.label}</span>`;
    dropdownContent.appendChild(outcomeDiv);
  });

  customDropdown.appendChild(dropdownBtn);
  customDropdown.appendChild(dropdownContent);
  dropdownContainer.appendChild(dropdownLabel);
  dropdownContainer.appendChild(customDropdown);
  dropdownGroup.appendChild(dropdownContainer);
  outcomeSelect.appendChild(dropdownGroup);
  outcomeBox.appendChild(outcomeTitle);
  outcomeBox.appendChild(outcomePopulation);
  outcomeBox.appendChild(calcMethodLink);
  outcomeBox.appendChild(outcomeSelect);
  stepHeader.appendChild(outcomeBox);

  const stepPopulation = document.createElement('div');
  stepPopulation.id = stepId;
  stepPopulation.classList.add('result');
  stepHeader.appendChild(stepPopulation);

  return stepHeader;
}

function prependStepHeaders() {
  const step2 = document.getElementById('step2');
  const step3 = document.getElementById('step3');

  if (step2) {
    step2.prepend(createStepHeader('step2-population'));
  }

  if (step3) {
    step3.prepend(createStepHeader('step3-population'));
  }
}

// Call the function to create and prepend the headers
prependStepHeaders();

// Add event listener to the EASI dropdown
document.querySelectorAll('.custom-dropdown .dropdown-content div').forEach(option => {
  option.addEventListener('click', (e) => {
    const selectedValue = e.target.dataset.value;
    const initialCostInput = document.querySelector('.initial-cost'); // Select the initial cost input
    const initialCost = parseFloat(initialCostInput.value) || 0; // Get the initial cost from the input
    const calculatedCost = initialCost * selectedValue;

    // Update the first column of the calc table with the calculated cost
    const calcTableFirstColumn = document.querySelector('.calc-table .first-column');
    if (calcTableFirstColumn) {
      calcTableFirstColumn.textContent = calculatedCost.toFixed(2);
    }

    // Update the dropdown button text
    const dropdownBtn = e.target.closest('.custom-dropdown').querySelector('.dropdown-btn span');
    if (dropdownBtn) {
      dropdownBtn.textContent = e.target.textContent;
    }
  });
});
