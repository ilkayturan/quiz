document.querySelectorAll('.custom-dropdown').forEach(dropdown => {
  const button = dropdown.querySelector('.dropdown-btn');
  const content = dropdown.querySelector('.dropdown-content');

  button.addEventListener('click', (event) => {
    event.stopPropagation();
    document.querySelectorAll('.dropdown-content').forEach(c => {
      if (c !== content) c.style.display = 'none';
    });
    content.style.display = content.style.display === 'block' ? 'none' : 'block';
  });

  content.querySelectorAll('div').forEach(option => {
    option.addEventListener('click', () => {
      button.textContent = option.textContent;
      content.style.display = 'none';
    });
  });

  document.addEventListener('click', () => {
    content.style.display = 'none';
  });
});

const container = document.getElementById("dropdownContainer");
const resultDiv = document.getElementById("populationResult");
const cities = {
  National: [
    { name: 'England', population: 541 },
    { name: 'Wales', population: 543 },
    { name: 'Northern Ireland', population: 643 },
  ],
  EnglandICB: [
    { name: 'England', population: 64 },
    { name: 'Wales', population: 543 },
    { name: 'Northern Ireland', population: 23 },
  ],
  NHSERegions: [
    { name: 'England', population: 43 },
    { name: 'Wales', population: 64 },
    { name: 'Northern Ireland', population: 214 },
  ],
  WalesHealthBoards: [
    { name: 'England', population: 134 },
    { name: 'Wales', population: 111 },
    { name: 'Northern Ireland', population: 521 },
  ],
  NIHealthandSocialCareTrusts: [
    { name: 'England', population: 123 },
    { name: 'Wales', population: 321 },
    { name: 'Northern Ireland', population: 320 },
  ],
  LAWales: [
    { name: 'England', population: 423 },
    { name: 'Wales', population: 21 },
    { name: 'Northern Ireland', population: 432 },
  ],
  LANI: [
    { name: 'England', population: 32 },
    { name: 'Wales', population: 12 },
    { name: 'Northern Ireland', population: 19 },
  ],
  LAEngland: [
    { name: 'England', population: 6 },
    { name: 'Wales', population: 5 },
    { name: 'Northern Ireland', population: 4 },
  ],
  EnglandCCGs: [
    { name: 'England', population: 3 },
    { name: 'Wales', population: 2 },
    { name: 'Northern Ireland', population: 1 },
  ]
};

function createDropdown(id, placeholder, options = []) {
  const dropdown = document.createElement('div');
  dropdown.classList.add('dropdown');
  dropdown.id = id;

  const selected = document.createElement('div');
  selected.classList.add('selected');
  selected.innerText = placeholder;

  const optionsDiv = document.createElement('div');
  optionsDiv.classList.add('options');

  options.forEach(option => {
    const optionElement = document.createElement('div');
    optionElement.classList.add('option');
    optionElement.dataset.value = option.value;
    optionElement.textContent = option.label;
    optionsDiv.appendChild(optionElement);
  });

  dropdown.appendChild(selected);
  dropdown.appendChild(optionsDiv);
  container.appendChild(dropdown);

  return { dropdown, selected, optionsDiv };
}

function setupDropdown(dropdown) {
  const selected = dropdown.querySelector('.selected');
  const options = dropdown.querySelector('.options');

  selected.addEventListener('click', () => {
    options.style.display = options.style.display === 'block' ? 'none' : 'block';
  });

  document.addEventListener('click', (e) => {
    if (!dropdown.contains(e.target)) {
      options.style.display = 'none';
    }
  });

  options.addEventListener('click', (e) => {
    if (e.target.classList.contains('option')) {
      selected.innerText = e.target.textContent;
      selected.dataset.value = e.target.dataset.value;
      options.style.display = 'none';
    }
  });
}

const { dropdown: regionDropdown, selected: regionSelected, optionsDiv: regionOptions } = createDropdown(
  "regionDropdown",
  "Select Region",
  [
    { label: 'National', value: 'National' },
    { label: 'England ICB', value: 'EnglandICB' },
    { label: 'NHSE Regions', value: 'NHSERegions' },
    { label: 'Wales Health Boards', value: 'WalesHealthBoards' },
    { label: 'NI Health and Social Care Trusts', value: 'NIHealthandSocialCareTrusts' },
    { label: 'LA Wales', value: 'LAWales' },
    { label: 'LA NI', value: 'LANI' },
    { label: 'LA England', value: 'LAEngland' },
    { label: 'England CCGs', value: 'EnglandCCGs' },
  ]
);

const { dropdown: cityDropdown, selected: citySelected, optionsDiv: cityOptions } = createDropdown(
  "cityDropdown",
  "Select City"
);

let selectedPopulation = null; // Variable to store the selected population

setupDropdown(regionDropdown);
setupDropdown(cityDropdown);

regionOptions.addEventListener('click', (e) => {
  if (e.target.classList.contains('option')) {
    const selectedRegion = e.target.dataset.value;
    citySelected.textContent = 'Select City';
    cityOptions.innerHTML = '';
    resultDiv.innerHTML = '&nbsp;';

    if (cities[selectedRegion]) {
      cities[selectedRegion].forEach(city => {
        const cityDiv = document.createElement('div');
        cityDiv.classList.add("option");
        cityDiv.dataset.value = city.population;
        cityDiv.textContent = city.name;
        cityOptions.appendChild(cityDiv);
      });

      cityOptions.style.display = 'block';

      // Automatically select the first option from the second dropdown
      const firstCityOption = cityOptions.querySelector('.option');
      if (firstCityOption) {
        citySelected.textContent = firstCityOption.textContent;
        citySelected.dataset.value = firstCityOption.dataset.value;
        resultDiv.textContent = `${firstCityOption.dataset.value}`;
        selectedPopulation = firstCityOption.dataset.value; // Update the selected population
        console.log(`Selected population: ${firstCityOption.dataset.value}`);

        // Update the element with id "step2-population"
        const step2PopulationElement = document.getElementById('step2-population');
        const step3PopulationElement = document.getElementById('step3-population');
        [step2PopulationElement, step3PopulationElement].forEach(element => {
          if (element) {
            element.textContent = selectedPopulation;
          }
        });
      }
    }
  }
});

cityOptions.addEventListener('click', (e) => {
  if (e.target.classList.contains('option')) {
    const population = e.target.dataset.value;
    resultDiv.textContent = `${population}`;
    selectedPopulation = population; // Update the selected population

    // Update the element with id "step2-population"
    const step2PopulationElement = document.getElementById('step2-population');
    const step3PopulationElement = document.getElementById('step3-population');
    [step2PopulationElement, step3PopulationElement].forEach(element => {
      if (element) {
        element.textContent = selectedPopulation;
      }
    });
  }
});

// Add a new element for the message under the dropdown
const messageDiv = document.createElement('div');
messageDiv.id = 'populationMessage';
messageDiv.style.color = 'red';
messageDiv.style.fontSize = 'small';
messageDiv.style.display = 'none';
messageDiv.textContent = 'Please select the population';
container.prepend(messageDiv);

// Page transition and Step indicator logic
document.querySelectorAll('.next-step, .prev-step').forEach(button => {
  button.addEventListener('click', () => {
    if (button.classList.contains('next-step') && !selectedPopulation) {
      messageDiv.style.display = 'block'; // Show the message
      return;
    }
    messageDiv.style.display = 'none'; // Hide the message
    const currentStep = button.closest('.step-one, .step-two, .step-three');
    const targetStep = button.classList.contains('next-step') ? currentStep.nextElementSibling : currentStep.previousElementSibling;
    currentStep.classList.add('hide');
    targetStep.classList.remove('hide');
    updateStepIndicators();
  });
});

const steps = [document.getElementById('step1'), document.getElementById('step2'), document.getElementById('step3')];
const stepIndicators = [document.getElementById('step-indicator1'), document.getElementById('step-indicator2'), document.getElementById('step-indicator3')];
stepIndicators.forEach((indicator, index) => indicator.innerHTML = index + 1);

function updateStepIndicators() {
  const checkmarkSVG = `<svg class="checkmark" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"
      stroke-linejoin="round"></path>
  </svg>`;

  stepIndicators.forEach((indicator, index) => {
    if (!steps[index].classList.contains('hide')) {
      indicator.innerHTML = index + 1;
      indicator.classList.add('active-step');
    } else {
      indicator.innerHTML = index + 1;
      indicator.classList.remove('active-step');
    }

    // Add checkmark to all previous steps
    if (index < steps.findIndex(step => !step.classList.contains('hide'))) {
      indicator.innerHTML = checkmarkSVG;
      indicator.classList.add('active-step');
    }
  });
}

updateStepIndicators();

function createStepHeader(stepId) {
  const stepHeader = document.createElement('div');
  stepHeader.classList.add('step-header');

  const outcomeBox = document.createElement('div');
  outcomeBox.classList.add('outcome-box');

  const outcomeTitle = document.createElement('h3');
  outcomeTitle.classList.add('outcome-title');
  outcomeTitle.textContent = 'Cost per responder';

  const outcomePopulation = document.createElement('div');
  outcomePopulation.classList.add('outcome-population');
  outcomePopulation.textContent = 'All outputs are modelled over a 1-year time frame';

  const calcMethodLink = document.createElement('a');
  calcMethodLink.href = '#';
  calcMethodLink.classList.add('calc-method-link');
  calcMethodLink.textContent = 'Methodology';

  const outcomeSelect = document.createElement('div');
  outcomeSelect.classList.add('outcome-select');

  const dropdownGroup = document.createElement('div');
  dropdownGroup.classList.add('dropdown-group');

  const dropdownContainer = document.createElement('div');
  dropdownContainer.classList.add('dropdown-container');

  const dropdownLabel = document.createElement('p');
  dropdownLabel.innerHTML = '<strong>Select an AD outcome&nbsp;</strong>';

  const customDropdown = document.createElement('div');
  customDropdown.classList.add('custom-dropdown');

  const dropdownBtn = document.createElement('button');
  dropdownBtn.type = 'button';
  dropdownBtn.classList.add('dropdown-btn');
  dropdownBtn.innerHTML = '<span>EASI 50</span>';

  const dropdownContent = document.createElement('div');
  dropdownContent.classList.add('dropdown-content');

  const outcomes = [
    { label: 'EASI 50', value: 0.5 },
    { label: 'EASI 75', value: 0.75 },
    { label: 'EASI 90', value: 0.9 },
    { label: 'IGA 0/1', value: 1.0 }
  ];

  outcomes.forEach(outcome => {
    const outcomeDiv = document.createElement('div');
    outcomeDiv.dataset.value = outcome.value;
    outcomeDiv.innerHTML = `<span>${outcome.label}</span>`;
    dropdownContent.appendChild(outcomeDiv);
  });

  customDropdown.appendChild(dropdownBtn);
  customDropdown.appendChild(dropdownContent);
  dropdownContainer.appendChild(dropdownLabel);
  dropdownContainer.appendChild(customDropdown);
  dropdownGroup.appendChild(dropdownContainer);
  outcomeSelect.appendChild(dropdownGroup);
  outcomeBox.appendChild(outcomeTitle);
  outcomeBox.appendChild(outcomePopulation);
  outcomeBox.appendChild(calcMethodLink);
  outcomeBox.appendChild(outcomeSelect);
  stepHeader.appendChild(outcomeBox);

  const stepPopulation = document.createElement('div');
  stepPopulation.id = stepId;
  stepPopulation.classList.add('result');
  stepHeader.appendChild(stepPopulation);

  return stepHeader;
}

function prependStepHeaders() {
  const step2 = document.getElementById('step2');
  const step3 = document.getElementById('step3');

  if (step2) {
    step2.prepend(createStepHeader('step2-population'));
  }

  if (step3) {
    step3.prepend(createStepHeader('step3-population'));
  }
}

// Call the function to create and prepend the headers
prependStepHeaders();

// Add event listener to the EASI dropdown
document.querySelectorAll('.custom-dropdown .dropdown-content div').forEach(option => {
  option.addEventListener('click', (e) => {
    const selectedValue = e.target.dataset.value;
    const initialCostInput = document.querySelector('.initial-cost'); // Select the initial cost input
    const initialCost = parseFloat(initialCostInput.value) || 0; // Get the initial cost from the input
    const calculatedCost = initialCost * selectedValue;

    // Update the first column of the calc table with the calculated cost
    const calcTableFirstColumn = document.querySelector('.calc-table .first-column');
    if (calcTableFirstColumn) {
      calcTableFirstColumn.textContent = calculatedCost.toFixed(2);
    }

    // Update the dropdown button text
    const dropdownBtn = e.target.closest('.custom-dropdown').querySelector('.dropdown-btn span');
    if (dropdownBtn) {
      dropdownBtn.textContent = e.target.textContent;
    }
  });
});
